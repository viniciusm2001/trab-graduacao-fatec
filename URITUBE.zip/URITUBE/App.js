//DEFINE AS VARIAVEIS
const express = require('express');
const api = express();
const cors = require("cors");
const path = require("path")
const con = require("./config/conexao");
const rotinas = require("./utils/Rotinas")

//DECLARA AS PORTAS DO SERVIDORES
const porta_api = 2009;
 
//'CONFIGURANDO' O CORS PARA NÃO HAVER
//ERROS DE CONEXÃO CAUSADOS PELO MESMO
api.get("*", cors());
api.post("*", cors());
api.put("*", cors());
api.patch("*", cors());
api.delete("*", cors());
api.head("*", cors());

api.options('*', (req, res, next) => {
  res.setHeader('Access-Control-Allow-Headers', '*');
  next();
});

api.options("*", cors());

api.use(express.json({ limit: "6mb" }));

api.use("/auth", require("./rotas/RotaAuth"));
api.use("/usuario", require("./rotas/RotaUsuario"));
api.use("/video", require("./rotas/RotaVideo"));
api.use("/comentario", require("./rotas/RotaComentario"));
api.use("/imagens", express.static(path.join(__dirname, "imagens")))

api.get("/", (req, res)=>{
   res.send("<h3>Você está na rota \\ da API<h3>")
});

api.listen(porta_api, () => {
   console.log("API ouvindo na porta " + porta_api);
	
   con
     .authenticate()
     .then(() => {
       console.log("Conexão com o banco efetuada com sucesso!");
		 rotinas()
     })
     .catch(err => {
       console.error("Erro ao efetuar conexão com o banco: ", err);
     });
});

//Configurnado as rotas do front-end (views)
const front_end = express();
const ejs = require("ejs")
const porta_front_end = 80;

front_end.set("view engine", "ejs")

front_end.get("/login", (req, res) => { res.render("login") })
front_end.get("/", (req, res) => { res.redirect(301, "/inicio") })
front_end.get("/inicio", (req, res) => { res.render("inicio") })
front_end.get("/enviar-video", (req, res) => { res.render("enviar-video") })
front_end.get("/video/:url_id", (req, res) => { res.render("video") })
front_end.get("/pesquisa/:termo_pesquisa", (req, res) => { res.render("pesquisa") })
front_end.get("/meus-videos", (req, res) => { res.render("meus-videos") })
front_end.get("/criar-conta", (req, res) => { res.render("criar-conta") })
front_end.get("/editar-conta", (req, res) => { res.render("editar-conta") })
front_end.get("/canal/:url_id", (req, res) => { res.render("canal") })

front_end.use(express.static(path.join(__dirname, "public")))

front_end.listen(porta_front_end, () => {
   console.log("Front-end ouvindo na porta " + porta_front_end);
})