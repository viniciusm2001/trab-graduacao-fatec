const { exec } = require('child_process');
const ffmpeg_path = require('ffmpeg-static');
const ffprobe_path = require('ffprobe-static').path;
const ffp = require('ffprobe');
const FsUtils = require("./FsUtils")
const DtUtils = require("./DtUtils")
const Utils = require("./Utils")

class ProcVideo {	

	static getResolucoes(){
		const res = [
			//3840 * 2160
			{
				base: 8294400, min: 7464960, max: 9123840,
				largura: 3840, altura: 2160, medio: 2880, apelido: "4K"
			},
			//2560 * 1440
			{
				base: 3686400, min: 3317760, max: 4055040,
				largura: 2560, altura: 1440, medio: 1920, apelido: "2K"
			},
			//1920 * 1080
			{
				base: 2073600, min: 1866240, max: 2280960,
				largura: 1920, altura: 1080, medio: 1440, apelido: "HD"
			},
			//1280 * 720
			{
				base: 921600, min: 829440, max: 1013760,
				largura: 1280, altura: 720, medio: 960, apelido: "HD"
			},
			//854 * 480
			{
				base: 409920, min: 368928, max: 450912,
				largura: 854, altura: 480, medio: 640, apelido: "SD"
			},
			//640 * 360
			{
				base: 230400, min: 207360, max: 253440,
				largura: 640, altura: 360, medio: 480, apelido: "SD"
			},
			//426 * 240
			{
				base: 102240, min: 92016, max: 112464,
				largura: 426, altura: 240, medio: 319, apelido: "SD"
			}
		]

		return Object.assign([], res);
	}

	static async ffprobe(caminho) {
		return new Promise(async (resolve, reject) => {
			
			try {
				const info = await ffp(caminho, {path: ffprobe_path});
				resolve(info);

			} catch(err) {
				reject(err);
			}
		})
	}

	static async ffmpeg(comando) {
		return new Promise((resolve, reject) => {
			
			const cmd = '"' + ffmpeg_path + '"' + ' -n ' + comando;
			
			exec(cmd, (err, stdout, stderr) => {
				if(err) {
					reject(err);
				} else {
					resolve();
				}
			})
		})
	}

	static getBestVideo(info){
		let index = -1;
		let melhor_resolucao = -1;

		for(let i = 0; i < info.streams.length; i++){
			if(info.streams[i].codec_type == "video"){
				const { height, width } = info.streams[i]
				const resolucao = height * width
			
				if(resolucao > melhor_resolucao){
					melhor_resolucao = resolucao
					index = i
				}
			}
		}
		
		return info.streams[index]
	}

	static getBestAudio(info){
		let index = -1;
		let mais_canais = -1;

		for(let i = 0; i < info.streams.length; i++){
			if(info.streams[i].codec_type == "audio"){

				const n_canais = info.streams[i].channels

				if(n_canais > mais_canais){
					mais_canais = n_canais
					index = i
				}
			}
		}

		return info.streams[index]
	}
	
	static async iniciar(vid){
		return new Promise(async (resolve, reject) => {

			const url_id = vid.url_id
			const caminho_base = "./videos/" + url_id
			const caminho_arq_original = caminho_base + "/arquivo-original.video"
			const caminho_destino = caminho_base + "/arquivos"
			
			try {
				await FsUtils.criarPasta(caminho_destino)

				const info_video = await ProcVideo.ffprobe(caminho_arq_original)
				//console.log(info_video)

				const video = ProcVideo.getBestVideo(info_video)
				const audio = ProcVideo.getBestAudio(info_video)

				const total_pixels = video.width * video.height
				const ar = video.width / video.height

				//index resolucao video
				let irv = null
				let fps = 0
				let cont_width = true
				let resolucoes = ProcVideo.getResolucoes()
				
				for(let i = 0; i < resolucoes.length; i++){
					if(total_pixels >= resolucoes[i].base * 0.7){
						if(total_pixels <= resolucoes[i].base * 1.3){
							irv = i
							break
						}
					}
				}

				if(irv == null){
					throw "Resolução não suportada, mínimo 240p (426 x 240) máximo 4K (3840 x 2160)"
				}

				if(ar < 1){
					for(let i = 0; i < resolucoes.length; i++){
						const { altura, largura } = resolucoes[i];
						resolucoes[i].largura = altura
						resolucoes[i].altura = largura
					}
				}

				if(video.width < resolucoes[irv].largura){
					cont_width = false
				}

				if(video.r_frame_rate.includes("/")){
					const [n1, n2] = video.r_frame_rate.split("/")
					fps = Math.ceil(parseInt(n1) / parseInt(n2))
				} else {
					fps = Math.ceil(parseFloat(video.r_frame_rate))
				}

				if(fps >= 59) {
					fps = 60
				}

				try {
					
					Object.assign(vid, {
						duracao: DtUtils.getDuracao(video.duration)
					});
	
					await vid.save()

					await ProcVideo.ffmpeg('-ss ' + parseInt(parseFloat(video.duration)/2) + ' -i ' + '"' + caminho_arq_original + 
						'" -vframes 1 -vf "crop=\'' + (ar > (16/9) ? 'ih*(16/9):ih:(iw-ow)/2:0' : 'iw:ih:0:0') +
						'\',scale=\'' + (cont_width ? resolucoes[5].largura + ':-1' : '-1:' + resolucoes[5].altura) + ':flags=lanczos\',' + 
						'pad=\'ceil(iw/2)*2:ceil(ih/2)*2\'" "' + caminho_destino + '/thumbnail.jpg"')

					for(let i = resolucoes.length - 1; i >= irv; i--){

						const qualidade = (ar < 1 ? resolucoes[i].largura : resolucoes[i].altura) + 'p'
	
						Object.assign(vid, { status: 'Processando qualidade ' + qualidade});
						console.log('Processando qualidade ' + qualidade)
	
						await vid.save()
						
						let cmd = ""

						if(!audio){
							if(video) {
								cmd = '-i ' + '"' + caminho_arq_original + '" -map 0:' + video.index +
									' -vf "scale=\'' + (cont_width ? resolucoes[i].largura + ':-1' : '-1:' + resolucoes[i].altura) + ':flags=lanczos\',' +
									'pad=\'ceil(iw/2)*2:ceil(ih/2)*2\',setsar=1,format=yuv420p" -c:v libx264 -profile:v baseline -an ' + 
									'-movflags +faststart -r 60000/1001 "' + caminho_destino + '/' +
									qualidade + (fps > 39 ? " [" + resolucoes[i].apelido + " " + fps + "FPS]" : " [" + resolucoes[i].apelido + "]")  + '.mp4"'
							} else {
								throw "Ao menos uma faixa de video é necessária"
							}

						} else {
							if(video) {
								cmd = '-i ' + '"' + caminho_arq_original + '" -map 0:' + video.index + ' -map 0:' + audio.index +
									' -vf "scale=\'' + (cont_width ? resolucoes[i].largura + ':-1' : '-1:' + resolucoes[i].altura) + ':flags=lanczos\',' +
									'pad=\'ceil(iw/2)*2:ceil(ih/2)*2\',setsar=1,format=yuv420p" -c:v libx264 -profile:v baseline' + (audio.channels > 2 ? ' -ac 2' : '') + 
									' -c:a aac -b:a ' + (resolucoes[i].qualidade > 480 ? 192 : 128) + "k " + '-movflags +faststart -r 60000/1001 "' + caminho_destino + '/' +
									qualidade + (fps > 39 ? " [" + resolucoes[i].apelido + " " + fps + "FPS]" : " [" + resolucoes[i].apelido + "]")  + '.mp4"'
							} else {
								throw "Ao menos uma faixa de video é necessária"
							}
						}
						
	
						await ProcVideo.ffmpeg(cmd)
					}

				} catch (err){
					console.log(err)
					throw "Não foi possivel processar o video, formato não reconhecido"
				}

				resolve();
			} catch(err) {
				reject(err)
			}

		})
	}

	static salvarImagem(imagem_base64, tipo){
		return new Promise(async (resolve, reject) => {
			
			let caminho_foto = ""

			try {
				await FsUtils.criarPasta("./imagens")

				while(true){
					let id = Utils.gerarId()
					caminho_foto = "./imagens/" + id + ".imagem";

					if(!(await FsUtils.pastaOuArqExiste(caminho_foto))){
						await FsUtils.salvarImgBase64(imagem_base64, caminho_foto)
						break
					}
				}

				const { streams: [ foto ] } = await ProcVideo.ffprobe(caminho_foto)

				let resolucao = {}

				let { altura, largura } = ProcVideo.getResolucoes()[5]

				const ar = foto.width / foto.height;
				const cont_width = ar >= 1 ? true : false

				if(ar < 1){
					resolucao = { altura: largura, largura: altura }
				} else {
					resolucao = { altura, largura }
				}
				
				if(tipo == "thumbnail"){
					await ProcVideo.ffmpeg('-ss 0 -i "' + caminho_foto + '" ' + 
						'-vframes 1 -vf "crop=\'' + (ar > (16/9) ? 'ih*(16/9):ih:(iw-ow)/2:0' : 'iw:ih:0:0') +
						'\',scale=\'' + (cont_width ? resolucao.largura + ':-1' : '-1:' + resolucao.altura) + ':flags=lanczos\',' + 
						'pad=\'ceil(iw/2)*2:ceil(ih/2)*2\'" "' + Utils.mudarExtensao(caminho_foto, "jpg") + '"')
				} else {
					await ProcVideo.ffmpeg('-ss 0 -i "' + caminho_foto + '" ' + 
						'-vframes 1 -vf "crop=\'' + (cont_width ? "ih:ih:(iw-ow)/2:0" : "iw:iw:0:(ih-oh)/2") 
						+ '\',scale=\'360:360:flags=lanczos\'" "' + Utils.mudarExtensao(caminho_foto, "jpg") + '"')
				}

				await FsUtils.deletarArquivo(caminho_foto)
				
				caminho_foto = caminho_foto.replace(/.\//, "/")

				resolve(Utils.mudarExtensao(caminho_foto, "jpg"))
				
			} catch(err) {

				if(await FsUtils.pastaOuArqExiste(caminho_foto)){
					await FsUtils.deletarArquivo(caminho_foto)
				}

				caminho_foto = Utils.mudarExtensao(caminho_foto, "jpg")

				if(await FsUtils.pastaOuArqExiste(caminho_foto)){
					await FsUtils.deletarArquivo(caminho_foto)
				}
				console.trace(err)
				reject("Formato não suportado, tente utilizar arquivos .jpeg, .jpg ou .png")
			}
		})
	}
}

module.exports = ProcVideo