const Video = require("../models/Rel").Video
const VideoRemovido = require("../models/Rel").VideoRemovido
const procVideo = require("./ProcVideo").iniciar
const controllerVideo = require("../controller/ControllerVideo")
const Sequelize = require("sequelize")
const { Op } = Sequelize

module.exports = () => {
	//change
	setInterval(async () => {
		try {
			let video = await Video.findOne({ 
				where: { status: null, [Op.and]: Sequelize.literal("video_removido.id IS NULL") },
				include: { model: VideoRemovido, required: false }, 
				order: [["criado_em", "ASC"]], attributes: ["id", "url_id", "id_usuario"]
			})
			
			if(video){
				try {
					await procVideo(video)

					Object.assign(video, { status: "" });
					
					await video.save()
					
				} catch (err) {
					console.trace(err)

					Object.assign(video, { status: 
						'Erro (' + (video.id_usuario ? 'por favor remova o seu video' : 'seu video foi removido') + 
						'): ' + (typeof err == "string" ? err : err.message), status_err: true });
					
					await video.save()
	
					if(!video.id_usuario){
						controllerVideo.removerVideo(video, "Erro ao processar video")
					} else {
						controllerVideo.removerVideo(video, null)
					}
				}
			}

		} catch(err) {
			console.trace(err)
		}

	}, 5000)
}