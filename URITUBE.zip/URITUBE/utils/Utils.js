class Utils {

	static errToJSON(err) {
		JSON.parse(JSON.stringify(err, Object.getOwnPropertyNames(err)))
		return err
	}

	static jsonIncOrRem(tipo, array, json){
		
		let new_json = {};

		const campos_json = Object.keys(json);

		for(let o = 0; o < campos_json.length; o++){
			for(let i = 0; i < array.length; i++){

				if(tipo == "incluir"){
					if(campos_json[o] == array[i]){
						new_json[campos_json[o]] = json[campos_json[o]]	
					} else {
						continue
					}
				} else {
					if(campos_json[o] != array[i]){
						new_json[campos_json[o]] = json[campos_json[o]]
						
					} else {
						new_json[campos_json[o]] = undefined
						break
					}
				}
			}
		}
		
	  	return new_json
	}

	static setErrJSON(message, json){
		
		if(!json){
			json = {errors:[]}
		}

		json.errors.push({ message })
		return json
	}

	static gerarId(){
	
		const tamanho_id = 15;
		const letras_e_numeros = "abcdefghijklmnopqrstuvwxyz0123456789";
	
		let id = "";
		
		for(let i = 0; i < tamanho_id; i++){
			//gera posição aleatoria
			const pos = Math.floor(Math.random() * letras_e_numeros.length);
			id += letras_e_numeros[pos];
		}
	
		return id
	}

	static copiarStringAteChar(string, char) {
		let nova_string = "";

		for (let i = 0; i < string.length; i++) {
			if(string[i] !== char) {
				nova_string += string[i];
			} else {
				break;
			}
		}

		return nova_string;
	}

	static mudarExtensao(caminho, extensao) {
		let array = caminho.split(".");

		array[array.length - 1] = extensao;

		return array.join(".");
	}

}


module.exports = Utils