const jwt = require('jsonwebtoken');

class JwtAuth {

   static getKey() {
      return "als982yh38o9udjka09usj3olj-ck";
   }

   static opcional(req, res, next) {
		
		req.token_opcional = true;

		if(req.headers['authorization']){
			if(req.headers['authorization'] != ""){
				req.token_opcional = false
			}
		}
      
		req.dadosToken = {}
		next()
   }

   static verificarToken(req, res, next) {

		if(!req.token_opcional){
			//PEGA O VALOR DO HEADER AUTHORIZATION
			let header_auth_value = req.headers['authorization'];
	
			if (header_auth_value) {
				//SEPARA A PALAVRA 'BEARER' DO TOKEN, PRA ASSIM CONSEGUIR O MESMO
				const token = header_auth_value.split(" ")[1];
	
				jwt.verify(token, JwtAuth.getKey(), { algorithms: ["HS512"] },(err, dadosToken)=>{
					if(err){
						//403 proibido
						console.log(err)
						res.sendStatus(403).end();
					} else {
	
						req.dadosToken = dadosToken;
						next();
					}
			  });
				
			} else {
				//412 pré condição na requisição falhou (na hora de enviar a requisi- 
				//ção, o cabeçalho (header) do 'authorization' juntamente com o valor 
				//'Bearer numero_do_token' está faltando)
				res.sendStatus(412).end();
			}
		} else {
			next();
		}
   }

	static async signToken(dados, opcoes_token) {
		
		return new Promise ((resolve, reject) => {
			
			opcoes_token.algorithm = "HS512"

			jwt.sign(dados, this.getKey(), opcoes_token, (err, token) => {
				if (err) {
					//500 Erro do servidor
					console.log("Erro ao gerar token: " + err)
					reject(new Error("Não foi possivel gera o token"))

				} else {
					resolve(token)
				}
			})
		})
	}
   
}

module.exports = JwtAuth;