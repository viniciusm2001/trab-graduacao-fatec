const fs = require("fs")

class FsUtils {
	static pastaOuArqExiste(caminho){
		return new Promise(async resolve => {
			try{
				await fs.promises.access(caminho)
				resolve(true)
			} catch(err) {
				resolve(false)
			}
		})
	}

	static criarPasta(caminho){
		return new Promise(async (resolve, reject) => {
			try {
				await fs.promises.mkdir(caminho, { recursive: true })
				resolve();
			} catch (err) {
				reject(err)
			}
		})
	}

	static salvarImgBase64(base64, caminho){
		return new Promise(async (resolve, reject) => {
			try {
				await fs.promises.writeFile(caminho, base64.split(",")[1], {encoding: "base64"})
				resolve();
			} catch (err) {
				reject(err)
			}
		})
	}
	
	static async deletarArquivo(caminho_arquivo){
		return new Promise((resolve, reject) => {
			fs.unlink(caminho_arquivo, err => {
				if(err){
					reject(err);
				} else {
					resolve();
				}
			});
		})
	}
	
	static async deletarPasta(caminho_pasta){
		return new Promise((resolve, reject) => {
			fs.rmdir(caminho_pasta, err => {
				if(err){
					reject(err);
				} else {
					resolve();
				}
			})
		})
	}

	static async getArquivosPasta(caminho) {
		return new Promise((resolve, reject) => {
			fs.readdir(caminho, (err, arqs_da_pasta) => {
				if(err) {
					reject(err)
				} else {
					resolve(arqs_da_pasta);
				}
			})
		})
	}

	static async deletarArquivosDaPasta(caminho_pasta){
		return new Promise(async (resolve, reject) => {
			let arquivos = [];

			let index = 0;

			const del = async () => {

				if(index == arquivos.length){
					resolve();

				} else {

					try{
						await this.deletarArquivo(caminho_pasta + "/" + arquivos[index]);
						index += 1;
						del();

					} catch(err){
						reject(err)
					}
				}
			}
			
			try {
				arquivos = await this.getArquivosPasta(caminho_pasta);
				del();
			} catch(err) {
				reject(err)
			}
			
		})
	}
	
	static async deletarPastaEArquivosDentro(caminho_pasta){
		return new Promise(async (resolve, reject) => {
			try {
				await this.deletarArquivosDaPasta(caminho_pasta);
				await this.deletarPasta(caminho_pasta);
				resolve();

			} catch(err) {
				reject(err)
			}
		})
	}
	
	static async getInfoArquivo(caminho){
		return new Promise(async (resolve, reject) => {
			try {
				const info_arquivo = await fs.promises.stat(caminho)
				resolve(info_arquivo);

			} catch(err) {
				reject(err)
			}
		})
	}
}

module.exports = FsUtils