const express = require('express');
const router = express.Router();
const controllerComentario = require("../controller/ControllerComentario");
const Auth = require("../utils/JwtAuth");

router.post('/', Auth.verificarToken, controllerComentario.criar);
router.post('/gostei/:id_comentario', Auth.verificarToken, controllerComentario.gostar);
router.post('/n-gostei/:id_comentario', Auth.verificarToken, controllerComentario.nGostar);

router.patch('/:id_comentario', Auth.verificarToken, controllerComentario.editar);

router.delete('/:id_comentario', Auth.verificarToken, controllerComentario.excluir);

router.get('/:url_id_video/:offset', Auth.opcional, Auth.verificarToken, controllerComentario.buscar);




module.exports = router;