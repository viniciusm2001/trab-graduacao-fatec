const express = require('express');
const router = express.Router();
const controllerAuth = require("../controller/ControllerAuth");
const Auth = require("../utils/JwtAuth");

router.post('/login/usuario', async (req, res) => {
	
   const {status, json} = await controllerAuth.logar("usuario",  req.body);
	json ? res.status(status).json(json) : res.status(status).end();
});

router.post('/login/admin', async (req, res) => {

   const {status, json} = await controllerAuth.logar("admin",  req.body);
	json ? res.status(status).json(json) : res.status(status).end();
});

router.post('/confirmar', Auth.verificarToken, (req, res) => {

   const id = req.dadosToken.usuario.id;

   const senha = req.body.senha;

   controllerAuth.confirmar(id, senha, (status)=>{
      
      res.status(status).end();
      
   });

});

module.exports = router;