const express = require('express');
const router = express.Router();
const controllerVideo = require("../controller/ControllerVideo");
const Auth = require("../utils/JwtAuth");

router.post('/', controllerVideo.enviar);
router.post('/info', Auth.verificarToken, controllerVideo.addVideoInfo);
router.post('/gostei/:id_video', Auth.verificarToken, controllerVideo.gostar);
router.post('/n-gostei/:id_video', Auth.verificarToken, controllerVideo.nGostar);

router.patch('/:url_id', Auth.verificarToken, controllerVideo.editar);

router.delete('/:url_id', Auth.verificarToken, controllerVideo.deletarVideo);

router.get('/:url_id/status', Auth.verificarToken, controllerVideo.getStatus)
router.get('/:url_id/recomendados/:offset', controllerVideo.getRecomendados)
router.get('/:url_id/para-assistir', Auth.opcional, Auth.verificarToken, controllerVideo.getVideoParaAssitir)
router.get('/:url_id/thumbnail', controllerVideo.getVideoThumbnail)
router.get('/:url_id/:qualidade', controllerVideo.getVideoArquivo)
router.get('/:url_id/:qualidade/:nome_arquivo/download', controllerVideo.getVideoArquivo)
router.get('/pagina-inicial/:tipo/:offset', controllerVideo.getPaginaInicial)
router.get('/pesquisa/:termo_pesquisa/:order_by/:offset', controllerVideo.getResultadosPesquisa)
router.get('/canal/:url_id/:order_by/:offset', controllerVideo.getCanal)
router.get('/gerenciamento/:order_by/:offset', Auth.verificarToken, controllerVideo.getGerenciamento)

module.exports = router;