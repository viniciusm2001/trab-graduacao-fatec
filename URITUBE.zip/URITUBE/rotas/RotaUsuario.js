const express = require('express');
const router = express.Router();
const controllerUsuario = require("../controller/ControllerUsuario");
const Auth = require("../utils/JwtAuth");

router.post('/', controllerUsuario.criar);

router.patch('/', Auth.verificarToken, controllerUsuario.editar);

router.delete('/', Auth.verificarToken, controllerUsuario.deletar);

router.get('/info-canal/:url_id', Auth.opcional, Auth.verificarToken, controllerUsuario.getInfoCanal);

module.exports = router;