const ul_erros = _("ul_erros")
const qualidade = _("qualidade")
const descricao = _("descricao")
const t_descricao = _("toggle_descricao")
const video_gostei = _("gostei")
const video_n_gostei = _("n_gostei")
const total_gostei = _("total_gostei")
const total_n_gostei = _("total_n_gostei")
const baixar_video_txt = _("baixar_video_txt")
const baixar_video = _("baixar_video")
const comentario = _("comentario")
const cmts = _("comentarios")
const btn_cancelar_edicao = _("cancelar_edicao")
const form_comentario = _("form_comentario")
let id_video = null
let player = null
let url_id = null
let titulo = null
let offset_comentarios = 0
let carregando_comentarios = false
let offset_recomendados = 0
let carregando_recomendados = false
let id_comentario_editando = -1
remover_carregando = false

const atualizar_barra_reacao_video = () => {

	const total_reacao_gostei = parseInt(total_gostei.innerHTML)

	let total_gostei_e_n_gostei = total_reacao_gostei + parseInt(total_n_gostei.innerHTML)
	let largura_barra = 0

	if(total_gostei_e_n_gostei == 0){
		largura_barra = 50
	} else {
		largura_barra = parseInt((total_reacao_gostei / total_gostei_e_n_gostei) * 100)
	}

	_("barra_gostei").innerHTML = `
			<div class="progress-bar" role="progressbar" 
			style="width: ${largura_barra}%;" 
			aria-valuenow="${largura_barra}" 
			aria-valuemin="0" 
			aria-valuemax="100">
			</div>`;
}

const tocar_video = () => {
	const tocar_video_interval = setInterval(() => {
		if(player.paused()){
			const tocou = player.play()

			if (tocou !== undefined) {
				tocou.then(() => {
					clearInterval(tocar_video_interval)
				}).catch(() => {});
			}
		} else {
			clearInterval(tocar_video)
		}
	}, 300)
}

const buscar_video = async () => {
	try {
		
		url_id = window.location.pathname.split("/")[2]
		
		let { data : video } = await ax.get("/video/" + url_id + "/para-assistir", {
			headers: {
				"authorization": (usuario ? "Bearer " + token_usuario : "")
			}		  
		})

		id_video = video.id

		video.qualidades.sort(naturalSort)

		for(let i = 0; i < video.qualidades.length; i++){
			qualidade.innerHTML += 
			`<option value="${url_api}/video/${url_id}/${video.qualidades[i]}"
			${i == video.qualidades.length - 1 ? "selected" : ""}>
			${video.qualidades[i]}
			</option>`
		}
		
		video.gostei = video.gostei == null ? 0 :video.gostei
		video.n_gostei = video.n_gostei == null ? 0 : video.n_gostei
		titulo = video.titulo
		
		if(video.reacao_usuario != null){
			if(video.reacao_usuario){
				video_gostei.classList.add("text-primary")
			} else {
				video_n_gostei.classList.add("text-danger")
			}
		}

		total_gostei.innerHTML = video.gostei
		total_n_gostei.innerHTML = video.n_gostei
		_("titulo").innerHTML = `<h2>${titulo}</h2>`
		_("n_visualizacoes").innerHTML = video.visualizacoes
		_("enviado_em").innerHTML += video.criado_em

		atualizar_barra_reacao_video()

		if(video.descricao){
			descricao.innerHTML = video.descricao.replace(/\n/g, "<br>")
		} else {
			t_descricao.style.display = "none"
		}
		

		if(video.usuario){
			_("div_canal").innerHTML = `
			<div class="row row-cols-2" 
				onclick="window.location='/canal/${video.usuario.url_id}'" style="cursor: pointer">
				<div class="col-5 col-sm-2 col-md-2">
					<div class="container_img_1_1">
						<img
							src="${url_api + video.usuario.url_foto}"
							onerror="this.onerror=null; this.src='/img/sem foto.png'"
							alt="" class="img_ar_ft_perfil img_round">
					</div>
				</div>
				<div class="col-7 col-md-9 pb-2">
					<p class="fs-5 lh-1 fw-bold">
						${video.usuario.nome}
					</p>
					<p class="fs-6 lh-1">
					${video.usuario.n_inscritos} ${video.usuario.n_inscritos == 1 ? "inscrito" : "inscritos"}
					</p>
				</div>
			</div>`;
		} else {
			
			_("div_canal").innerHTML = `
			<div class="row row-cols-2">
				<div class="col-5 col-sm-2 col-md-2">
					<div class="container_img_1_1">
						<img
							src=""
							onerror="this.onerror=null; this.src='/img/sem foto.png'"
							alt="" class="img_ar_ft_perfil img_round">
					</div>
				</div>
				<div class="col-7 col-md-9 pb-2">
					<p class="fs-5 fw-bold">
						Anonimo
					</p>
				</div>
			</div>`;
		}
		
		player = videojs(_("video"), {
			controls: true,
			preload: 'auto',
			poster: (video.url_thumbnail ? 
							url_api + video.url_thumbnail : 
							`${url_api}/video/${url_id}/thumbnail`),
			userActions: {
				hotkeys: true
			}
		});

		player.ready(() => {
			remover_carregando = true
			player.src({ type: 'video/mp4', src: qualidade.value })
			baixar_video_txt.innerHTML = 
				qualidade[qualidade.selectedIndex].innerHTML;
			
			const btn_pip_mode = document.getElementsByClassName("vjs-picture-in-picture-control")[0];
			let entrou = 0;

			let obs_video = new IntersectionObserver((elementos) => {
				if(entrou < 1){ //select dos comentarios com like
					entrou += 1;
				} else {
					if(elementos[0].isIntersecting === true){
						if(player.isInPictureInPicture()){
							btn_pip_mode.click()
						}
					} else {
						if(!(player.isInPictureInPicture())){
							//btn_pip_mode.click()
						}
					}
				}
			}, { threshold: [0] });
			
			obs_video.observe(_("video"));

			_("div_pagina_video").style.display = "block"
			tocar_video()
		});

	} catch (err){
		render_erros(err, ul_erros)
		remover_carregando = true
	}
}

buscar_video()

const trocar_qualidade = () => {
	//const caminho_video = api_url + "/" + qualidade.value
	const caminho_video = qualidade.value

	const tempo_atual = player.currentTime()

	player.src({ type: 'video/mp4', src: caminho_video });

	player.currentTime(tempo_atual)

	tocar_video()

	baixar_video_txt.innerHTML = 
		qualidade[qualidade.selectedIndex].innerHTML;
}

const toggle_descricao = () => {
	if(descricao.style.display == "none"){
		descricao.style.display = "block";

		t_descricao.innerHTML = "Ocultar descrição"

	} else {
		descricao.style.display = "none"
		t_descricao.innerHTML = "Ver descrição"
	}
}

let obs_carregando_recomendados = new IntersectionObserver(async (elementos) => {
	if(elementos[0].isIntersecting === true){
		if(!carregando_recomendados && offset_recomendados !== -1){

			carregando_recomendados = true

			let { data : recomendados } = await ax.get("/video/" + url_id + "/recomendados/" + offset_recomendados)
			
			if(recomendados.length == 0){
				offset_recomendados = -1
				
				setTimeout(() => {
					_("carregando_recomendados").style.display = "none"
				}, 1500)

			} else {

				_("carregando_recomendados").style.display = "none"

				for(let i = 0; i < recomendados.length; i++){
					
					_("recomendados").innerHTML += `
					<div class="row mt-3" onclick="window.location='/video/${recomendados[i].url_id}'" 
						style="cursor: pointer">
							<div class="col-6 col-md-4 col-xl-3">
								<div class="container_img_16_9">
									<img
										src="${recomendados[i].url_thumbnail ? 
													url_api + recomendados[i].url_thumbnail : 
													`${url_api}/video/${recomendados[i].url_id}/thumbnail`}"
										onerror="this.onerror=null; this.src='/img/sem thumbnail.jpg'"
										alt="" class="img_ar">
										<h6 class="tempo_video">
											<span class="badge bg-dark">${recomendados[i].duracao}</span>
										</h6>
								</div>
							</div>
							<div class="col-6 col-md-8 col-xl-9">
								<h5 class="text-truncate-2-linhas">
									${recomendados[i].titulo}
								</h5>
								<h6 class="text-truncate">
									${recomendados[i].usuario.nome}
								</h6>
								<p class="fs-6 text-truncate">${recomendados[i].visualizacoes} visualizações</p>
							</div>
							<p class="text-center mt-2"><small class="text-muted">Enviado ${recomendados[i].criado_em}</small></p>
							<hr>
					</div>
					`
					
					setTimeout(() => {
						_("carregando_recomendados").style.display = "block"
					}, 500)
				}

				offset_recomendados++;
			}

			carregando_recomendados = false
		}
	}
}, { threshold: [0] });

obs_carregando_recomendados.observe(
	_("carregando_recomendados")
);

let obs_carregando_comentarios = new IntersectionObserver(async (elementos) => {
	if(elementos[0].isIntersecting === true){
		if(!carregando_comentarios && offset_comentarios !== -1){

			carregando_comentarios = true

			let { data : comentarios } = await ax.get("/comentario/" + url_id + "/" + offset_comentarios, 
			{
				headers: {
					"authorization": (usuario ? "Bearer " + token_usuario : "")
				}		  
			})
			
			if(comentarios.length == 0){
				offset_comentarios = -1

				setTimeout(() => {
					_("carregando_comentarios").style.display = "none"
				}, 1500)

			} else {

				_("carregando_comentarios").style.display = "none"

				for(let i = 0; i < comentarios.length; i++){
					
					cmts.innerHTML += `
					<div id="div_comentario_${comentarios[i].id}" class="row row-cols-3 mt-3">
						<div class="col-3 col-sm-2 col-md-1">
							<a href="${"/canal/" + comentarios[i].url_id}">
								<div class="container_img_1_1">
									<img
									src="${url_api + comentarios[i].url_foto}"
										onerror="this.onerror=null; this.src='/img/sem foto.png'"
										alt="" class="img_ar_ft_perfil img_round">
								</div>
							</a>
						</div>
						<div class="col-8 col-sm-9 col-md-10" style="position: relative">
							
							${comentarios[i].url_id == (usuario ? usuario.url_id : null) ? `
							<div class="btn-group dropstart" style="position: absolute; right:0; top:-10px">
								<button class="btn btn-primary dropdown-toggle" type="button" id="menu_comentario_${comentarios[i].id}" data-bs-toggle="dropdown" aria-expanded="false"
									style="background-color: transparent !important; color: black; 
									outline: none; border: none; box-shadow: none; min-width: 40px; max-height="10px">
								</button>
								<ul class="dropdown-menu" aria-labelledby="menu_comentario_${comentarios[i].id}">
									<li onclick="editar_comentario(${comentarios[i].id})"><button class="dropdown-item" type="button">Editar</button></li>
									<li onclick="excluir_comentario(${comentarios[i].id})"><button class="dropdown-item" type="button">Excluir</button></li>
								</ul>
							</div>` : ""}

							<span class="fs-5 lh-1 fw-bold">
								${comentarios[i].nome}
							</span> 
							<div></div>
							<small class="text-muted">${comentarios[i].criado_em} ${comentarios[i].is_editado ? "(Editado)" : ""}</small>
							<p id="comentario_${comentarios[i].id}"
								class="text-break mt-2 ${comentarios[i].comentario.length > 100 ? "text-truncate" : ""}">

								${comentarios[i].comentario.replace(/\n/g, "<br>")}
							</p>
							<div></div>
							${comentarios[i].comentario.length > 100 ? `
							<span
								onclick="toggle_comentario(${comentarios[i].id}, this)"
								style="cursor: pointer; width: 30%;"
								class="mx-auto text-center toggle_comentario
								text-secondary text-decoration-underline">Ler mais</span>	
							` : ""}
						</div>
						<div class="col-1">
							<a href="#!" 
								id="gostei_comentario_${comentarios[i].id}"
								onclick="gostei_comentario(${comentarios[i].id}, this)"
								class="${comentarios[i].reacao_usuario == 1 ? "text-primary" : ""} link-simples" 
								style="text-decoration: none !important; font-size: 125%;">

								<i class="bi bi-hand-thumbs-up-fill"></i>
							</a>
								<span id="valor_gostei_comentario_${comentarios[i].id}">
									${comentarios[i].num_gostei == null ? 0 : comentarios[i].num_gostei}
								</span>
							<div></div>
							<a href="#!" 
								id="n_gostei_comentario_${comentarios[i].id}"
								onclick="n_gostei_comentario(${comentarios[i].id}, this)"
								class="${comentarios[i].reacao_usuario == 0 ? "text-danger" : ""} link-simples"
								style="font-size: 125%;">

								<i class="bi bi-hand-thumbs-down-fill"></i>
							</a>
							
							<span id="valor_n_gostei_comentario_${comentarios[i].id}">
								${comentarios[i].num_n_gostei == null ? 0 : comentarios[i].num_n_gostei}
							</span>
						</div>
					</div>
					`

					setTimeout(() => {
						_("carregando_comentarios").style.display = "block"
					}, 500)
				}

				offset_comentarios++;
			}

			carregando_comentarios = false
		}
	}
}, { threshold: [0] });

obs_carregando_comentarios.observe(
	_("carregando_comentarios")
);

const toggle_comentario = (id_comentario, el) => {

	_("comentario_" + id_comentario).classList.toggle("text-truncate")
	
	if(el.innerHTML == "Ler mais") {
		el.innerHTML = "Ler menos"
	} else {
		el.innerHTML = "Ler mais"
	}
}

const diminuir_em_um = (el) => {
	el.innerHTML = parseInt(el.innerHTML) - 1
}

const acrescentar_em_um = (el) => {
	el.innerHTML = parseInt(el.innerHTML) + 1
}

const gostei_comentario = async (id_comentario, el) => {

	if(!token_usuario){
		alert("Ação necessita de login")
		return
	}

	ul_erros.style.display = "none"

	try {
		await ax.post("/comentario/gostei/" + id_comentario,
			null,
			{
				headers: {
					"authorization": "Bearer " + token_usuario
				}		  
			})
		
		const n_gostei_comentario = _("n_gostei_comentario_" + id_comentario)

		if(n_gostei_comentario.classList.contains("text-danger")){
			n_gostei_comentario.classList.remove("text-danger")
			diminuir_em_um(_("valor_n_gostei_comentario_" + id_comentario))
		}
	
		if(el.classList.contains("text-primary")){
			diminuir_em_um(_("valor_gostei_comentario_" + id_comentario))
		} else {
			acrescentar_em_um(_("valor_gostei_comentario_" + id_comentario))
		}
	
		el.classList.toggle("text-primary")

	} catch (err) {
		render_erros(erro, ul_erros)
	}
}

const n_gostei_comentario = async (id_comentario, el) => {

	if(!token_usuario){
		alert("Ação necessita de login")
		return
	}

	ul_erros.style.display = "none"

	try {
		await ax.post("/comentario/n-gostei/" + id_comentario,
			null,
			{
				headers: {
					"authorization": "Bearer " + token_usuario
				}		  
			})

		const gostei_comentario = _("gostei_comentario_" + id_comentario)

		if(gostei_comentario.classList.contains("text-primary")){
			gostei_comentario.classList.remove("text-primary")
			diminuir_em_um(_("valor_gostei_comentario_" + id_comentario))
		}
	
		if(el.classList.contains("text-danger")){
			diminuir_em_um(_("valor_n_gostei_comentario_" + id_comentario))
		} else {
			acrescentar_em_um(_("valor_n_gostei_comentario_" + id_comentario))
		}
	
		el.classList.toggle("text-danger")

	} catch (err) {
		render_erros(erro, ul_erros)
	}
}

const gostei_video = async () => {

	if(!token_usuario){
		alert("Ação necessita de login")
		return
	}

	ul_erros.style.display = "none"

	try {
		await ax.post("/video/gostei/" + id_video,
			null,
			{
				headers: {
					"authorization": "Bearer " + token_usuario
				}		  
			})

		if(video_n_gostei.classList.contains("text-danger")){
			video_n_gostei.classList.remove("text-danger")
			diminuir_em_um(total_n_gostei)
		}
	
		if(video_gostei.classList.contains("text-primary")){
			diminuir_em_um(total_gostei)
		} else {
			acrescentar_em_um(total_gostei)
		}
	
		video_gostei.classList.toggle("text-primary")

		atualizar_barra_reacao_video()

	} catch (err) {
		render_erros(erro, ul_erros)
	}
}

const n_gostei_video = async () => {

	if(!token_usuario){
		alert("Ação necessita de login")
		return
	}

	ul_erros.style.display = "none"

	try {
		await ax.post("/video/n-gostei/" + id_video,
			null,
			{
				headers: {
					"authorization": "Bearer " + token_usuario
				}		  
			})

		if(video_gostei.classList.contains("text-primary")){
			video_gostei.classList.remove("text-primary")
			diminuir_em_um(total_gostei)
		}
	
		if(video_n_gostei.classList.contains("text-danger")){
			diminuir_em_um(total_n_gostei)
		} else {
			acrescentar_em_um(total_n_gostei)
		}
	
		video_n_gostei.classList.toggle("text-danger")

		atualizar_barra_reacao_video()

	} catch (err) {
		render_erros(erro, ul_erros)
	}
}

const baixar_o_video = () => {
	window.open(qualidade.value + "/" + titulo + "/download", "_blank")
}

const enviar_comentario = async (e) => {

	e.preventDefault();

	ul_erros.style.display = "none"

	if(!token_usuario){
		alert("Ação necessita de login")
		return
	}

	if(comentario.value.length < 3 || comentario.value.length > 9999){
		render_erros("No minimo 3 caracteres e no maximo 9999", ul_erros)
		return
	}
	
	try {

		if(id_comentario_editando == -1){
			let { data : cm } = await ax.post("/comentario", 
			{
				id_video,
				comentario: comentario.value
			},
			{
				headers: {
					"authorization": "Bearer " + token_usuario
				}		  
			})

			cmts.innerHTML = `
				<div id="div_comentario_${cm.id}" class="row row-cols-3 mt-3">
					<div class="col-3 col-sm-2 col-md-1">
						<a href="${"/canal/" + usuario.url_id}">
							<div class="container_img_1_1">
								<img
								src="${url_api + usuario.url_foto}"
									onerror="this.onerror=null; this.src='/img/sem foto.png'"
									alt="" class="img_ar_ft_perfil img_round">
							</div>
						</a>
					</div>
					<div class="col-8 col-sm-9 col-md-10" style="position: relative">

						<div class="btn-group dropstart" style="position: absolute; right:0; top:-10px">
							<button class="btn btn-primary dropdown-toggle" type="button" id="menu_comentario_${cm.id}" data-bs-toggle="dropdown" aria-expanded="false"
								style="background-color: transparent !important; color: black; 
								outline: none; border: none; box-shadow: none; min-width: 40px; max-height="10px">
							</button>
							<ul class="dropdown-menu" aria-labelledby="menu_comentario_${cm.id}">
								<li onclick="editar_comentario(${cm.id})"><button class="dropdown-item" type="button">Editar</button></li>
								<li onclick="excluir_comentario(${cm.id})"><button class="dropdown-item" type="button">Excluir</button></li>
							</ul>
						</div>

						<span class="fs-5 lh-1 fw-bold">
							${usuario.nome}
						</span> 
						<div></div>
						<small class="text-muted">${cm.criado_em}</small>
						<p id="comentario_${cm.id}"
							class="text-break mt-2 ${cm.comentario.length > 100 ? "text-truncate" : ""}">

							${cm.comentario.replace(/\n/g, "<br>")}
						</p>
						<div></div>
						${cm.comentario.length > 100 ? `
						<span
							onclick="toggle_comentario(${cm.id}, this)"
							style="cursor: pointer; width: 30%;"
							class="mx-auto text-center toggle_comentario
							text-secondary text-decoration-underline">Ler mais</span>	
						` : ""}
					</div>
					<div class="col-1">
						<a href="#!" 
							id="gostei_comentario_${cm.id}"
							onclick="gostei_comentario(${cm.id}, this)"
							class="link-simples" 
							style="text-decoration: none !important; font-size: 125%;">

							<i class="bi bi-hand-thumbs-up-fill"></i>
						</a>
							<span id="valor_gostei_comentario_${cm.id}">
								0
							</span>
						<div></div>
						<a href="#!" 
							id="n_gostei_comentario_${cm.id}"
							onclick="n_gostei_comentario(${cm.id}, this)"
							class="link-simples"
							style="font-size: 125%;">

							<i class="bi bi-hand-thumbs-down-fill"></i>
						</a>
						
						<span id="valor_n_gostei_comentario_${cm.id}">
							0
						</span>
					</div>
				</div>` + cmts.innerHTML;
			
	 		} else {

				await ax.patch("/comentario/" + id_comentario_editando, 
				{
					comentario: comentario.value
				},
				{
					headers: {
						"authorization": "Bearer " + token_usuario
					}		  
				})

				btn_cancelar_edicao.style.display = "none"

				const comentario_em_edicao = _("comentario_" + id_comentario_editando)

				comentario_em_edicao.innerHTML = comentario.value.replace(/\n/g, "<br>")

				id_comentario_editando = -1

				scroll_ate_elemento(comentario_em_edicao)
			}

			comentario.value = ""
	} catch(err) {
		render_erros(err, ul_erros)
	}
}

const editar_comentario = (id_comentario) => {

	id_comentario_editando = id_comentario

	ul_erros.style.display = "none" 

	btn_cancelar_edicao.style.display = "block"

	comentario.value = _("comentario_" + id_comentario).innerHTML.trim().replace(/<br>/g, "\n")

	scroll_ate_elemento(form_comentario)
}

const excluir_comentario = async (id_comentario) => {
	
	if(!token_usuario){
		alert("Ação necessita de login")
		return
	}

	if(confirm("Deseja excluir este comentário?")){
		try {
			await ax.delete("/comentario/" + id_comentario,
				{
					headers: {
						"authorization": "Bearer " + token_usuario
					}		  
				})
			
			_("div_comentario_" + id_comentario).style.display = "none"
		} catch(err) {
			render_erros(err, ul_erros)
		}
	}
	
}

const cancelar_edicao = () => {
	btn_cancelar_edicao.style.display = "none"

	const comentario_em_edicao = _("comentario_" + id_comentario_editando)

	comentario.value = ""

	scroll_ate_elemento(comentario_em_edicao)
}

qualidade.addEventListener("change", trocar_qualidade)
t_descricao.addEventListener("click", toggle_descricao)
video_gostei.addEventListener("click", gostei_video)
video_n_gostei.addEventListener("click", n_gostei_video)
baixar_video.addEventListener("click", baixar_o_video)
form_comentario.addEventListener("submit", enviar_comentario)
btn_cancelar_edicao.addEventListener("click", cancelar_edicao)