const ul_erros = _("ul_erros")

if(usuario){
	alert("Você já está logado")
	window.location.href = "/inicio"
}

const criar_conta = async (e) => {
	
	e.preventDefault()
	
	ul_erros.style.display = "none"

	try {
		
		if(_("senha1").value != _("senha2").value){
			throw "Senhas diferentes, por favor digite-as novamente"
		}

		await ax.post("/usuario", 
			{
				email: _("email").value,
				senha: sha512(_("senha1").value),
				nome: _("nome").value,
				url_id: _("url_id").value
			})

		alert("Conta criada com sucesso, agora você será redirecionado para o login")

		setTimeout(() => {
			window.location.href = "/login"
		}, 300)

	} catch(err) {
		render_erros(err, ul_erros)
	}
}

_("criar_conta_form").addEventListener("submit", criar_conta)