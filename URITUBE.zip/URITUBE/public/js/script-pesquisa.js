const ul_erros = _("ul_erros")
const resultados = _("resultados")
const carregando_resultados = _("carregando_resultados")
let offset = 0
let is_carregando_resultados = false
let order_by = "mais-visualizacoes"

const termo_pesquisa = window.location.pathname.split("/")[2]

_("titulo_principal").innerHTML += decodeURI("\"" + termo_pesquisa + "\"")

let obs_carregando_resultados = new IntersectionObserver(async (elementos) => {
	if(elementos[0].isIntersecting === true){
		if(!is_carregando_resultados && offset !== -1){

			is_carregando_resultados = true

			let { data : videos } = await ax.get("/video/pesquisa/" + termo_pesquisa + "/" + order_by + "/" + offset)
			
			if(videos.length == 0){
				offset = -1
				
				setTimeout(() => {
					carregando_resultados.style.display = "none"
				}, 1500)

			} else {

				carregando_resultados.style.display = "none"

				for(let i = 0; i < videos.length; i++){
					
					resultados.innerHTML += `
					<div class="col pt-3" onclick="window.location='/video/${videos[i].url_id}'" 
						style="cursor: pointer">
						<div class="row">
							<div class="col-6 col-md-4 col-xl-3">
								<div class="container_img_16_9">
									<img
										src="${videos[i].url_thumbnail ? 
													url_api + videos[i].url_thumbnail : 
													`${url_api}/video/${videos[i].url_id}/thumbnail`}"
										onerror="this.onerror=null; this.src='/img/sem thumbnail.jpg'"
										alt="" class="img_ar">
										<h6 class="tempo_video">
											<span class="badge bg-dark">${videos[i].duracao}</span>
										</h6>
								</div>
							</div>
							<div class="col-6 col-md-8 col-xl-9">
								<h5 class="text-truncate-2-linhas">
									${videos[i].titulo}
								</h5>
								<h6 class="text-truncate">
									${videos[i].usuario.nome}
								</h6>
								<p class="fs-6 text-truncate">${videos[i].visualizacoes} visualizações</p>
							</div>
							<p class="text-center mt-3"><small class="text-muted">Enviado ${videos[i].criado_em}</small></p>
							<hr style="margin-bottom: 0px">
						</div>
					</div>
					`

					setTimeout(() => {
						carregando_resultados.style.display = "block"
					}, 500)
				}

				offset++;
			}

			is_carregando_resultados = false
		}
	}
}, { threshold: [0] });

obs_carregando_resultados.observe(
	carregando_resultados
);

const ordenar_por = (tipo) => {
	carregando_resultados.style.display = "none"

	resultados.innerHTML = ""

	offset = 0

	order_by = tipo

	setTimeout(() => {
		carregando_resultados.style.display = "block"
	}, 100)
}