const ul_erros = _("ul_erros")
const ul_erros2 = _("ul_erros2")
const foto_upload = _("foto_upload")
const senha_atual = _("senha_atual")
const nome = _("nome")
const url_id = _("url_id")
const novo_email = _("novo_email")
const senha1 = _("senha1")
const senha2 = _("senha2")
let foto_base64 = null

if (!usuario) {
	alert("Você precisa estar logado para acessar esta página")
	window.location.href = "/inicio"
} else {
	nome.value = usuario.nome
	url_id.value = usuario.url_id
}

const editar = async (e) => {
	
	e.preventDefault()
	
	ul_erros.style.display = "none"

	if(foto_base64){
		if(foto_base64 > 5500000){
			alert("Imagem muito grande, por favor selecione outra")
			return
		}
	}

	try {

		if(senha1.value && senha2.value){
			if(senha1.value != senha2.value){
				throw "Senhas diferentes, por favor digite-as novamente"
			}
		}

		const { data: { token: tok, usuario: usr } } = 
			await ax.patch("/usuario", 
			{
				nome: nome.value,
				url_id: url_id.value,
				novo_email: novo_email.value ? novo_email.value : null,
				senha: sha512(senha_atual.value),
				nova_senha: senha1.value ? sha512(senha1.value) : null,
				foto_base64
			},
			{
				headers: {
					"authorization": "Bearer " + token_usuario
				}		  
			})
		
		localStorage.setItem("token", tok);
		localStorage.setItem("usuario", JSON.stringify(usr));
		
		alert("Conta editada com sucesso!")
		
		setTimeout(() => {
			window.location.href = "/editar-conta"
		}, 500)

	} catch(err) {
		render_erros(err, ul_erros)
	}
}

const remover = async (e) => {
	
	e.preventDefault()
	
	ul_erros2.style.display = "none"

	if (confirm("Deseja excluir a sua conta permanentemente?")) {
		try {
			await ax.delete("/usuario",
				{
					headers: {
						"authorization": "Bearer " + token_usuario,
						"senha": sha512(_("senha_atual2").value)
					}		  
				})
			
			localStorage.removeItem("token");
			localStorage.removeItem("usuario");
			
			alert("Conta excluida com sucesso!")
			
			setTimeout(() => {
				window.location.href = "/inicio"
			}, 500)
	
		} catch(err) {
			render_erros(err, ul_erros2)
		}
	}
}

const converter_imagem = () => {
	const foto = foto_upload.files[0]
	
	let reader = new FileReader()

	reader.onloadend = () => {

		foto_base64 = reader.result
		
		if(foto_base64.length > 5500000){
			alert("Imagem muito grande, por favor selecione outra")
		}
	}

	reader.readAsDataURL(foto)
}

_("editar_conta_form").addEventListener("submit", editar)
_("deletar_conta_form").addEventListener("submit", remover)
foto_upload.addEventListener("change", converter_imagem)