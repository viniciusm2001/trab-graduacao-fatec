const ul_erros = _("ul_erros")

let carregando_populares_hoje = false
let carregando_populares_esta_semana = false
let carregando_enviados_recentemente = false
let offset_populares_hoje = 0
let offset_populares_esta_semana = 0
let offset_enviados_recentemente = 0

let obs_carregando = new IntersectionObserver(async (elementos) => {
	
	let ie = -1

	for(let i = 0; i < elementos.length; i++){
		if(elementos[i].isIntersecting === true){
			ie = i
			break
		}
	}
	
	if(ie != -1){
		
		let offset = -1
		let tipo = ""

		if(elementos[ie].target.id == "carregando_populares_hoje"){
			
			if(carregando_populares_hoje){
				return
			}

			if(offset_populares_hoje == -1){
				return
			} else {
				offset = offset_populares_hoje
				tipo = "populares-hoje"
			}
			
			carregando_populares_hoje = true
			

		} else if(elementos[ie].target.id == "carregando_populares_esta_semana"){
			
			if(carregando_populares_esta_semana){
				return
			}

			if(offset_populares_esta_semana == -1){
				return
			} else {
				offset = offset_populares_esta_semana
				tipo = "populares-esta-semana"
			}
			
			carregando_populares_esta_semana = true
			

		} else {

			if(carregando_enviados_recentemente){
				return
			}

			if(offset_enviados_recentemente == -1){
				return
			} else {
				offset = offset_enviados_recentemente
				tipo = "enviados-recentemente"
			}

			carregando_enviados_recentemente = true
		}

		let { data : videos } = await ax.get("/video/pagina-inicial/" + tipo + "/" + offset)
		
		if(videos.length == 0){
			
			if(elementos[ie].target.id == "carregando_populares_hoje"){
				offset_populares_hoje = -1
				
			} else if(elementos[ie].target.id == "carregando_populares_esta_semana"){
				offset_populares_esta_semana = -1
				
			} else {
				offset_enviados_recentemente = -1
			}
			
			setTimeout(() => {
				_(elementos[ie].target.id).style.display = "none"
			}, 1500)

		} else {

			_(elementos[ie].target.id).style.display = "none"

			for(let i = 0; i < videos.length; i++){
				
				_("div-" + tipo).innerHTML += `
				<div class="col" 
					onclick="window.location='/video/${videos[i].url_id}'" 
					style="cursor: pointer">
					<div class="card mb-3">
						<div class="container_img_16_9" style="background-color: black;">
							<img
								src="${videos[i].url_thumbnail ? 
									url_api + videos[i].url_thumbnail : 
									`${url_api}/video/${videos[i].url_id}/thumbnail`}"
								onerror="this.onerror=null; this.src='/img/sem thumbnail.jpg'"
								class="card-img-top img_ar" alt="...">
							<h6 class="tempo_video">
								<span class="badge bg-dark">${videos[i].duracao}</span>
							</h6>
						</div>
						
						<div class="card-body">
							<h5 class="card-title text-truncate-2-linhas mb-2">
								${videos[i].titulo}
							</h5>

							<div class="row row-cols-2 mt-3">
								<div class="col-3">
									<div class="container_img_1_1">
										<img
											src="${url_api + videos[i].usuario.url_foto}"
											onerror="this.onerror=null; this.src='/img/sem foto.png'"
											alt="" class="img_ar_ft_perfil img_round">
									</div>
								</div>
								<div class="col-9 row">

									<p class="fs-6 lh-1 fw-bold text-truncate" style="margin-bottom:5%">
										${videos[i].usuario.nome}
									</p>
									<p class="fs-6 lh-1 text-truncate">${videos[i].visualizacoes} visualizações</p>

								</div>
							</div>

							<p class="card-text" style="margin-top: 3%;"><small class="text-muted">Enviado ${videos[i].criado_em}</small></p>
						</div>
					</div>
				</div>
				`

				setTimeout(() => {
					_(elementos[ie].target.id).style.display = "block"
				}, 500)
				
			}

			if(elementos[ie].target.id == "carregando_populares_hoje"){
				offset_populares_hoje++
				
			} else if(elementos[ie].target.id == "carregando_populares_esta_semana"){
				offset_populares_esta_semana++
				
			} else {
				offset_enviados_recentemente++
			}
		}

		if(elementos[ie].target.id == "carregando_populares_hoje"){
			carregando_populares_hoje = false
			
		} else if(elementos[ie].target.id == "carregando_populares_esta_semana"){
			carregando_populares_esta_semana = false
			
		} else {
			carregando_enviados_recentemente = false
		}
		
	}
}, { threshold: [0] });

obs_carregando.observe(
	_("carregando_populares_hoje")
);

obs_carregando.observe(
	_("carregando_populares_esta_semana")
);

obs_carregando.observe(
	_("carregando_enviados_recentemente")
);