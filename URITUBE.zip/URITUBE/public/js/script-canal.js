const ul_erros = _("ul_erros")
const div_videos = _("div_videos")
const carregando_videos = _("carregando_videos")
let offset = 0
let is_carregando_videos = false
let order_by = "mais-recente"

const url_id = window.location.pathname.split("/")[2]

const carregar_info_canal = async () => {
	try {
		let { data : usr } = await ax.get("/usuario/info-canal/" + url_id, 
			{
				headers: {
					"authorization": (usuario ? "Bearer " + token_usuario : "")
				}		  
			})

			_("info_canal").innerHTML = `
				<div class="col-3 col-sm-2">
					<div class="container_img_1_1">
						<img
							src="${url_api + usr.url_foto}"
							onerror="this.onerror=null; this.src='/img/sem foto.png'"
							alt="" class="img_ar_ft_perfil img_round"  style="max-width: 150px; max-height: 150px;">
					</div>
				</div>
				
				<div class="col-9 col-sm-10">
	
					<h1 class="text-break text-truncate-2-linhas">
						${usr.nome}
					</h1>
					<h4>${usr.n_videos} Videos - ${usr.n_inscritos} Inscritos</h4>
					<h6>Canal criado em: ${usr.criado_em}</h6>
	
				</div>`
			
			

	} catch(err) {
		render_erros(err, ul_erros)
	}
}

carregar_info_canal()

_("div_canal").style.display = "block"
_("div_resto_canal").style.display = "block"

let obs_carregando_videos = new IntersectionObserver(async (elementos) => {
	if(elementos[0].isIntersecting === true){
		if(!is_carregando_videos && offset !== -1){

			is_carregando_videos = true

			let { data : videos } = await ax.get("/video/canal/" + url_id + "/" + order_by + "/" + offset)
			
			if(videos.length == 0){
				offset = -1
				
				setTimeout(() => {
					carregando_videos.style.display = "none"
				}, 1500)

			} else {

				carregando_videos.style.display = "none"

				for(let i = 0; i < videos.length; i++){
					
					div_videos.innerHTML += `
					<div class="col mt-3" onclick="window.location='/video/${videos[i].url_id}'" 
						style="cursor: pointer">
						<div class="card mb-3">
							<div class="container_img_16_9" style="background-color: black;">
								<img
									src="${videos[i].url_thumbnail ? 
										url_api + videos[i].url_thumbnail : 
										`${url_api}/video/${videos[i].url_id}/thumbnail`}"
									onerror="this.onerror=null; this.src='/img/sem thumbnail.jpg'"
									class="card-img-top img_ar" alt="...">
								<h6 class="tempo_video">
									<span class="badge bg-dark">${videos[i].duracao}</span>
								</h6>
							</div>
							
							<div class="card-body">
								<h5 class="card-title text-truncate-2-linhas mb-2">
									${videos[i].titulo}
								</h5>
								<p class="fs-6 lh-1 text-truncate">${videos[i].visualizacoes} visualizações</p>

								<p class="card-text" style="margin-top: 3%;"><small class="text-muted">Enviado ${videos[i].criado_em}</small></p>
							</div>
						</div>
					</div>
					`

					setTimeout(() => {
						carregando_videos.style.display = "block"
					}, 500)
				}

				offset++;
			}

			is_carregando_videos = false
		}
	}
}, { threshold: [0] });

obs_carregando_videos.observe(
	carregando_videos
);

const ordenar_por = (tipo) => {
	carregando_videos.style.display = "none"

	div_videos.innerHTML = ""

	offset = 0

	order_by = tipo

	setTimeout(() => {
		carregando_videos.style.display = "block"
	}, 100)
}