const ul_erros = _("ul_erros")

if(usuario){
	alert("Você já está logado")
	window.location.href = "/inicio"
}

const login_submit = async (e) => {
	
	e.preventDefault()
	
	ul_erros.style.display = "none"

	try {
		//throw "Err"
		const { data: { token: tok, usuario: usr } } = 
			await ax.post("/auth/login/usuario", 
			{
				email: _("email").value,
				senha: sha512(_("senha").value)
			})
		
		localStorage.setItem("token", tok);
		localStorage.setItem("usuario", JSON.stringify(usr));

		window.location.href = "/inicio"

	} catch(err) {
		let erro = ""

		switch (err.response.status) {
			case 423:
				erro = "Usuario removido"
				break;
		
			default:
				erro = "Não foi possivel fazer login, por favor cheque seu email e senha"
				break;
		}
		
		render_erros(erro, ul_erros)
	}
}

_("login_form").addEventListener("submit", login_submit)