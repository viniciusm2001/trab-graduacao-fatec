const url_api = 'http://127.0.0.1:2009'
let remover_carregando = true
let token_usuario = null
let usuario = null

const _ = (id) => {
	return document.getElementById(id)
}

const __ = (selector) => {
	return document.querySelector(selector)
}

const isVazio = (json) => {
	if(json
		&& Object.keys(json).length === 0
		&& Object.getPrototypeOf(json) === Object.prototype){
		return true
	} else{
		return false
	}
}

const round = (valor, precisao) => {
   const multiplicador = Math.pow(10, precisao || 0);
   return Math.round(valor * multiplicador) / multiplicador;
}

const getValorCss = (el, propriedade) => {
	return window.getComputedStyle(el).getPropertyValue(propriedade)
}

let ax = axios.create({
	baseURL: url_api
});

const scroll_ate_elemento = (el) => {
	
	function GetScreenCordinates(obj) {
		var p = {};
		p.x = obj.offsetLeft;
		p.y = obj.offsetTop;
		while (obj.offsetParent) {
			p.x = p.x + obj.offsetParent.offsetLeft;
			p.y = p.y + obj.offsetParent.offsetTop;
			if (obj == document.getElementsByTagName("body")[0]) {
				break;
			}
			else {
				obj = obj.offsetParent;
			}
		}
		return p;
	}
	
	const { x, y } = GetScreenCordinates(el)

	window.scrollTo(x, (y - 150))
}

const render_erros = (err, ul) => {

	let json = {};
	let erro = null
	
	ul.innerHTML = "";
	
	if(err.response?.data && 
		!isVazio(err.response?.data)){

		json = err.response.data

		if(typeof json == "string"){
			json = { errors: [{ message: json }] }
		}

	} else {
		erro = (typeof err == "string" ? err : err.message)
	}

	if(typeof erro == "string"){
		json = { errors: [{ message: erro }] }
	}
	
	json.errors.map(err => {
		
		console.error(err.message)

		ul.innerHTML += `
		<li class="list-group-item list-group-item-danger">
			${err.message}
		</li>
		`
	})

	ul.style.display = "block"

	window.scrollTo(0,0);

	return
}

const config_inicial = () => {
	const largura_do_dispositivo = document.getElementsByTagName("html")[0].clientWidth
	
	if(largura_do_dispositivo < 700){
		_("form_pesquisa_barra").style.position = "absolute"
		_("form_pesquisa_barra").style.left = "-9999%"
	} else {
		_("form_pesquisa_off").style.position = "absolute"
		_("form_pesquisa_off").style.left = "-9999%"
	}

	if ('scrollRestoration' in history) {
		history.scrollRestoration = 'manual';
	}
  
  	window.scrollTo(0,0);

	token_usuario = localStorage.getItem("token")
	usuario = JSON.parse(localStorage.getItem("usuario"))

	if(!token_usuario){
		const elementos_logado = document.getElementsByClassName("logado")

		for(let i = 0; i < elementos_logado.length; i++){
			elementos_logado[i].style.display = "none"
		}

	} else {
		
		const elementos_n_logado = document.getElementsByClassName("n_logado")

		for(let i = 0; i < elementos_n_logado.length; i++){
			elementos_n_logado[i].style.display = "none"
		}
		
		_("bem_vindo").innerHTML = `
		<div class="row row-cols-2">
			<div class="col-3">
				<div class="container_img_1_1">
					<img
						src="${url_api + usuario.url_foto}"
						onerror="this.onerror=null; this.src='/img/sem foto.png'"
						alt="" class="img_ar_ft_perfil img_round">
				</div>
			</div>
			<div class="col-9">
				<div class="row fw-bold" style="font-size: 125%;">
					Bem vindo
				</div>
				<div class="row" style="font-size: 125%;">
					${usuario.nome}
				</div>
				<div id="sair_conta"
				class="row text-secondary" style="font-size: 110%; cursor: pointer">
					Sair
				</div>
			</div>
		</div>`

		_("sair_conta").addEventListener("click", () => {
			localStorage.removeItem("token");
			localStorage.removeItem("usuario");
			window.location.href = "/inicio"
		})

		_("link_meu_canal").href = "/canal/" + usuario.url_id
	}
}

window.addEventListener("load", () => {
	const carregando = _("carregando")
	carregando.style.dsiplay = "block"
	let rodando = false
	
	const checar = setInterval(() => {
		if(!rodando){
			if(remover_carregando){

				rodando = true;
				let opacity = 1

				const escurecer = setInterval(() => {
					opacity -= 0.01
					carregando.style.opacity = opacity

					if(opacity <= 0){
						carregando.style.display = "none"
						clearInterval(escurecer)
						clearInterval(checar)
					}
				}, 1);
			}
		}
		
	}, 500)
});

config_inicial()

const pesquisar = (e) => {
	e.preventDefault()
	
	const pesquisa_barra = _("pesquisa_barra")
	const pesquisa_off = _("pesquisa_off")
	let termo_pesquisa = ""

	if(pesquisa_barra.value.trim() == ""){
		if(pesquisa_off.value.trim() == "") {
			alert("Por favor, preencha o campo de pesquisa")
			return
		} else {
			termo_pesquisa = pesquisa_off.value.trim()
		}
	} else {
		termo_pesquisa = pesquisa_barra.value.trim()
	}
	
	window.location.href = "/pesquisa/" + termo_pesquisa
}

_("form_pesquisa_barra").addEventListener("submit", pesquisar)
_("form_pesquisa_off").addEventListener("submit", pesquisar)