let is_uploading = false;
const ul_erros = _("ul_erros")
const enviar = _("enviar");
const cancel_upload = axios.CancelToken.source();
const video_upload = _("video_upload")

if(!usuario){
	_("is_privado").checked = true
	_("is_privado").disabled = true
}

const video_upload_submnit = async (e) => {
	
	e.preventDefault()
	
	ul_erros.style.display = "none"

	if(video_upload.files[0].size > 2147483648){
		render_erros(
			"Tamanho máximo de 2GB por video"
			, ul_erros)
	} else {

		const mimetypes_permitidos = /avi|divx|msvideo|video\/mp4|video\/quicktime/;

		//Checa a mimetype (tipo do arquivo)
		const mimetype = mimetypes_permitidos.test(video_upload.files[0].type)

		if (!mimetype){
			render_erros(
				"Somente videos no formato mp4, avi e mov são permitdos"
				, ul_erros)
		} else {
			const form_data = new FormData();
			form_data.append("video_upload", video_upload.files[0])

			try {
				is_uploading = true
				enviar.disabled = true;

				const { data: { url_id, token } } = await ax.post("/video",
					form_data,
					{
						CancelToken: cancel_upload.token,
						headers: {
							"content-type": "multipart/form-data"
						},
						onUploadProgress: (progress) => {
							enviar.innerHTML = 
								round((progress.loaded/progress.total) * 100) 
								+ "% do envio concluido";
						},			  
					})
					
				await ax.post("/video/info", 
					{
						titulo: _("titulo").value,
						descricao: _("descricao").value,
						is_privado: _("is_privado").checked,
						url_id
					},
					{
						headers: {
							"authorization": "Bearer " + (usuario ? token_usuario : token)
						}		  
					})

				is_uploading = false
				
				if(!usuario){

					let i = 4

					let intervalo_carregando = setInterval(() => {
						
						if(i > 3){
							i = 1
							enviar.innerHTML = "Envio concluido, aguarde o inicio do processamento";
						}

						enviar.innerHTML += "."
						i++

					}, 750)

					const checar_status = setInterval(async () => {
						try {
							const { data: { status } } = await ax.get("video/" + url_id + "/status",
								{
									headers: {
										"authorization" : "Bearer " + token
									}
								})

							if(!(status == null)){
								
								if(status === ""){
									clearInterval(checar_status)
									enviar.innerHTML = "Processamento concluido, aguarde alguns instantes";

									setTimeout(() => {
										window.location.href = "video/" + url_id
									}, 3000)

								} else {
									clearInterval(intervalo_carregando)
									enviar.innerHTML = status
								}
							}
						} catch(err) {
							render_erros(err, ul_erros)
						}
						
					//change
					}, 1000)

					
				} else {

					enviar.innerHTML = "Envio concluido, aguarde alguns instantes";

					setTimeout(() => {
						window.location.href = "meus-videos/"
					}, 3000)
				}

			} catch(err) {
				console.error(err)
				enviar.disabled = false;
				enviar.innerHTML = "Enviar";
				cancel_upload.cancel()
				is_uploading = false
				render_erros(err, ul_erros)
			}
		}
	}
}

const on_before_unload = (e) => {

	if (is_uploading) {
		e.preventDefault();
		e.returnValue = '';
		delete e['returnValue'];
		return;
	}

	delete e['returnValue'];
}

window.addEventListener('beforeunload', on_before_unload);
_("video_upload_form").addEventListener("submit", video_upload_submnit)