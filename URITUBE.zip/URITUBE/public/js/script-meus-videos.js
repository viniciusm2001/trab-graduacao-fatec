const ul_erros = _("ul_erros")
const ul_erros_editar = _("ul_erros_editar")
const div_videos = _("div_videos")
const carregando_videos = _("carregando_videos")
const modal_editar = _("modal_editar")
const modal = new bootstrap.Modal(modal_editar)
const titulo = _("titulo")
const descricao = _("descricao")
const is_privado = _("is_privado")
const thumbnail_upload = _("thumbnail_upload")
let thumbnail_base64 = null
let videos_do_usuario = []
let info_video_e = null
let offset = 0
let is_carregando_videos = false
let order_by = "mais-recente"

if (!usuario) {
	alert("Você precisa estar logado para acessar esta página")
	window.location.href = "/inicio"
}

const desativar_link = (el) => {
	if (!el.classList.contains("link-desabilitado")) {
		el.classList.add("link-desabilitado")
		el.style.cursor = "not-allowed"
	}
}

const ativar_link = (el) => {
	if (el.classList.contains("link-desabilitado")) {
		el.classList.remove("link-desabilitado")
		el.style.cursor = "pointer"
	}
}

const assistir_video = (url_id) => {
	if (getValorCss(_("assistir_video_" + url_id), "opacity") != "0.4") {

		ul_erros.style.display = "none"

		window.open("/video/" + url_id, "_blank")
	}
}

const editar_video = (url_id) => {
	//if(_("editar_video_" + url_id).style.display != "none"){
	if (getValorCss(_("editar_video_" + url_id), "opacity") != "0.4") {

		ul_erros.style.display = "none"
		info_video_e = videos_do_usuario[url_id]

		titulo.value = info_video_e.titulo
		descricao.value = info_video_e.descricao ? info_video_e.descricao : "" 
		is_privado.checked = info_video_e.is_privado

		modal.show()
	}
}

const converter_imagem = () => {
	const foto = thumbnail_upload.files[0]
	
	let reader = new FileReader()

	reader.onloadend = () => {

		thumbnail_base64 = reader.result
		
		if(thumbnail_base64.length > 5500000){
			alert("Imagem muito grande, por favor selecione outra")
		}
	}

	reader.readAsDataURL(foto)
}

const salvar = async () => {
	if(info_video_e){

		if(thumbnail_base64){
			if(thumbnail_base64 > 5500000){
				alert("Imagem muito grande, por favor selecione outra")
				return
			}
		}

		ul_erros_editar.style.display = "none"

		try {
			const { data: vid } = await ax.patch("/video/" + info_video_e.url_id, 
			{
				titulo: titulo.value,
				descricao: descricao.value.trim() ? descricao.value.trim() : null,
				is_privado: is_privado.checked,
				thumbnail_base64
			},
			{
				headers: {
					"authorization": "Bearer " + token_usuario
				}		  
			})
		
			videos_do_usuario[vid.url_id] = {
				url_id: vid.url_id,
				titulo: vid.titulo,
				descricao: vid.descricao,
				is_privado: vid.is_privado,
				url_thumbnail: vid.url_thumbnail
			}

			_("titulo_video_" + vid.url_id).innerHTML = vid.titulo
			
			if(vid.url_thumbnail){
				_("img_video_" + vid.url_id).src = url_api + vid.url_thumbnail
			}
			
			_("visibilidade_video_" + vid.url_id).innerHTML = vid.is_privado ? "Privado" : "Público"

			info_video_e = null
			thumbnail_base64 = null
			modal.hide()

			setTimeout(() => {
				alert("Video editado com sucesso!")
			}, 500)

		} catch(err) {
			console.log(err)
			render_erros(err, ul_erros_editar)
		}
	}
}

const cancelar = () => {
	info_video_e = null
	thumbnail_base64 = null
}

const excluir_video = async (url_id) => {
	if (getValorCss(_("excluir_video_" + url_id), "opacity") != "0.4") {

		ul_erros.style.display = "none"

		if (confirm("Deseja excluir este video?")) {
			try {
				await ax.delete("/video/" + url_id,
					{
						headers: {
							"authorization": "Bearer " + token_usuario
						}
					})

				_("video_" + url_id).style.display = "none"

				setTimeout(() => {
					alert("Video excluido com sucesso!")
				}, 500)

			} catch (err) {
				render_erros(err, ul_erros)
			}
		}
	}
}

const monitorar_video = (url_id) => {

	const interval = setInterval(async () => {
		let { data: info_video } = await ax.get("/video/" + url_id + "/status",
			{
				headers: {
					"authorization": "Bearer " + token_usuario
				}
			})

		if (info_video.duracao) {
			_("tempo_video_" + url_id).style.display = "block"
			_("valor_tempo_video_" + url_id).innerHTML = info_video.duracao

			if (!info_video.url_thumbnail) {
				_("img_video_" + url_id).src = `${url_api}/video/${url_id}/thumbnail`
			} else {
				_("img_video_" + url_id).src = url_api + video_info.url_thumbnail
			}
		}

		if (info_video.status_err) {

			_("status_video_" + url_id).style.display = "none"
			_("status_err_video_" + url_id).style.display = "block"
			_("status_err_video_" + url_id).innerHTML = info_video.status

			desativar_link(_("editar_video_" + url_id))
			ativar_link(_("excluir_video_" + url_id))

			clearInterval(interval)
		} else {
			if (info_video.status !== "") {
				_("status_video_" + url_id).style.display = "block"

				if (info_video.status == null) {
					_("status_video_" + url_id).innerHTML = "Processamento começara em breve"
				} else {
					ativar_link(_("editar_video_" + url_id))
					_("status_video_" + url_id).innerHTML = info_video.status
				}

			} else {
				_("status_video_" + url_id).style.display = "none"

				ativar_link(_("editar_video_" + url_id))
				ativar_link(_("assistir_video_" + url_id))
				ativar_link(_("excluir_video_" + url_id))
				clearInterval(interval)
			}
		}


	}, 5000)
}

let obs_carregando_videos = new IntersectionObserver(async (elementos) => {

	if (!token_usuario) return

	if (elementos[0].isIntersecting === true) {
		if (!is_carregando_videos && offset !== -1) {

			is_carregando_videos = true

			let { data: videos } = await ax.get("/video/gerenciamento/" + order_by + "/" + offset,
				{
					headers: {
						"authorization": "Bearer " + token_usuario
					}
				})

			if (videos.length == 0) {
				offset = -1

				setTimeout(() => {
					carregando_videos.style.display = "none"
				}, 1500)

			} else {

				carregando_videos.style.display = "none"

				for (let i = 0; i < videos.length; i++) {

					if (videos[i].status !== "" && !videos[i].status_err) {
						monitorar_video(videos[i].url_id)
					}

					const info_video = {
						url_id: videos[i].url_id,
						titulo: videos[i].titulo,
						descricao: videos[i].descricao,
						is_privado: videos[i].is_privado,
						url_thumbnail: videos[i].url_thumbnail
					}

					videos_do_usuario[videos[i].url_id] = info_video

					div_videos.innerHTML += `
					<div id="video_${videos[i].url_id}" class="col mt-3">
						<div class="row">
							<div class="col-12 col-md-3">
								<div class="container_img_16_9">
									<img
										id="img_video_${videos[i].url_id}"
										src="${videos[i].url_thumbnail ?
										url_api + videos[i].url_thumbnail :
										`${url_api}/video/${videos[i].url_id}/thumbnail`}"
										onerror="this.onerror=null; this.src='/img/sem thumbnail.jpg'"
										alt="" class="img_ar">
										<h6 id="tempo_video_${videos[i].url_id}" class="tempo_video"
											style="${videos[i].duracao == null ? "display: none" : ""}">
											<span id="valor_tempo_video_${videos[i].url_id}"
											class="badge bg-dark">${videos[i].duracao}</span>
										</h6>
								</div>
							</div>
							<div class="col-12 col-md-9">
								<h2 id="titulo_video_${videos[i].url_id}" 
									 class="text-break text-truncate-2-linhas mt-2 mb-3">
									${videos[i].titulo}
								</h2>
								
								<div class="row">
									<div class="col-4 col-md-3">
										<div class="text-truncate fw-bold">
											Visualizações:
										</div>
										<div class="text-truncate">
											${videos[i].visualizacoes}
										</div>
									</div>
									
									<div class="col-4 col-md-2">
										<div class="fw-bold text-break">
											Gostei:
										</div>
										<div class="text-truncate">
										${videos[i].gostei ? videos[i].gostei : 0}
										</div>
									</div>
									
									<div class="col-4 col-md-2 mb-2">
										<div class="fw-bold text-break">
											Não gostei:
										</div>
										<div class="text-truncate">
											${videos[i].n_gostei ? videos[i].n_gostei : 0}
										</div>
									</div>
									
									<div class="col-6 col-md-3">
										<div class="fw-bold text-break">
											N° de comentarios:
										</div>
										<div class="text-truncate">
											${videos[i].num_comentarios ? videos[i].num_comentarios : 0}
										</div>
									</div>
									
									<div class="col-6 col-md-2">
										<div class="fw-bold text-break">
											Visibilidade:
										</div>
										<div 
										id="visibilidade_video_${videos[i].url_id}"
										class="text-truncate">
										${videos[i].is_privado ? "Privado" : "Público"}
										</div>
									</div>
								</div>
								
								<div class="row mt-3">
									<div class="col-4 text-center">
										<div id="assistir_video_${videos[i].url_id}" 
											class="link-simples${videos[i].status !== "" ? " link-desabilitado" : ""}" 
											style="font-size: 250%;  ${videos[i].status === "" && !videos[i].status_err ? "cursor: pointer" : ""}"
											onclick="assistir_video('${videos[i].url_id}')">
											<i class="bi bi-play-btn"></i>
										</div>
									</div>
									<div class="col-4 text-center">
										<div id="editar_video_${videos[i].url_id}" 
											class="link-simples${videos[i].status == null || videos[i].status_err ? " link-desabilitado" : ""}" 
											style="font-size: 200%; ${videos[i].status != null && !videos[i].status_err ? "cursor: pointer" : ""}"
											onclick="editar_video('${videos[i].url_id}')">
											<i class="bi bi-pencil-fill"></i>
										</div>
									</div>
									<div class="col-4 text-center">
										<div id="excluir_video_${videos[i].url_id}" 
											class="link-simples${videos[i].status !== "" && !videos[i].status_err ? " link-desabilitado" : ""}" 
											style="font-size: 200%; ${videos[i].status == "" || videos[i].status_err ? "cursor: pointer" : ""}"
											onclick="excluir_video('${videos[i].url_id}')">

											<i class="bi bi-trash-fill"></i>
										</div>
									</div>
								</div>
								
							</div>

							${videos[i].status !== "" ?
							`
								<p id="status_video_${videos[i].url_id}" class="fw-bold text-break text-center mt-2"
									style="${videos[i].status_err ? "display: none" : ""}">
									${videos[i].status != null ? videos[i].status : "Processamento começara em breve"}
								</p>
								
								<p id="status_err_video_${videos[i].url_id}" class="fw-bold text-break text-center mt-2" 
									style="color: red${!videos[i].status_err ? "; display: none" : ""}">
									${videos[i].status}
								</p>
								`
							: ""}

							<p class="text-center"><small class="text-muted">Enviado ${videos[i].criado_em}</small></p>
							<hr style="margin-bottom: 0px">
						</div>
					</div>
					`

					setTimeout(() => {
						carregando_videos.style.display = "block"
					}, 500)
				}

				offset++;
			}

			is_carregando_videos = false
		}
	}
}, { threshold: [0] });

obs_carregando_videos.observe(
	carregando_videos
);

const ordenar_por = (tipo) => {
	carregando_videos.style.display = "none"

	div_videos.innerHTML = ""

	offset = 0

	order_by = tipo

	setTimeout(() => {
		carregando_videos.style.display = "block"
	}, 100)
}

_("btn_salvar").addEventListener("click", salvar)
_("btn_cancelar").addEventListener("click", cancelar)
_("btn_fechar").addEventListener("click", cancelar)
thumbnail_upload.addEventListener("change", converter_imagem)