const Sequelize = require("sequelize");
const con = require("../config/conexao");

class Inscricao extends Sequelize.Model { }

Inscricao.init({
   id: {
      type: Sequelize.INTEGER,
      primaryKey: true,
      autoIncrement: true,
      allowNull: false
   },
   id_usuario_inscrito: {
      type: Sequelize.INTEGER,
		allowNull: false
   },
   id_usuario_principal: {
      type: Sequelize.INTEGER,
		allowNull: false
   }
},{
   timestamps: false,
   underscored: true,
   tableName: 'tbl_inscricao',
   modelName:'inscricao',
   sequelize: con
});

module.exports = Inscricao;