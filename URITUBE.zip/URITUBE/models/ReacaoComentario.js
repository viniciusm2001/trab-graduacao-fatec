const Sequelize = require("sequelize");
const con = require("../config/conexao");

class ReacaoComentario extends Sequelize.Model { }

ReacaoComentario.init({
   id: {
      type: Sequelize.INTEGER,
      primaryKey: true,
      autoIncrement: true,
      allowNull: false
   },
   gostei: {
      type: Sequelize.BOOLEAN,
      allowNull: false
   },
   id_comentario: {
      type: Sequelize.INTEGER,
      allowNull: false
   },
   id_usuario: {
      type: Sequelize.INTEGER,
      allowNull: false
   }
},{
   underscored: true,
   timestamps: false,
   tableName: 'tbl_reacao_comentario',
   modelName:'reacao_comentario',
   sequelize: con
});

module.exports = ReacaoComentario;