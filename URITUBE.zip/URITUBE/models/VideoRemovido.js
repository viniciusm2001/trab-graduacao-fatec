const Sequelize = require("sequelize");
const con = require("../config/conexao");

class VideoRemovido extends Sequelize.Model { }

VideoRemovido.init({
   id: {
      type: Sequelize.INTEGER,
      primaryKey: true,
      autoIncrement: true,
      allowNull: false
   },
   id_video: {
      type: Sequelize.INTEGER,
      allowNull: false
   },
   razao: {
      type: Sequelize.STRING(100),
      allowNull: false
   }
},{
   underscored: true,
   timestamps: false,
   tableName: 'tbl_video_removido',
   modelName:'video_removido',
   sequelize: con
});

module.exports = VideoRemovido;