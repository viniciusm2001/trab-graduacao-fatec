const Sequelize = require("sequelize");
const con = require("../config/conexao");

class UsuarioRemovido extends Sequelize.Model { }

UsuarioRemovido.init({
   id: {
      type: Sequelize.INTEGER,
      primaryKey: true,
      autoIncrement: true,
      allowNull: false
   },
   id_usuario: {
      type: Sequelize.INTEGER,
      allowNull: false
   },
   razao: {
      type: Sequelize.STRING(100),
      allowNull: false
   }
},{
   underscored: true,
   timestamps: false,
   tableName: 'tbl_usuario_removido',
   modelName:'usuario_removido',
   sequelize: con
});

module.exports = UsuarioRemovido;