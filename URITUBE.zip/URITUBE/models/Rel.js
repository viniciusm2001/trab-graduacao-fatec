const Usuario = require("./Usuario");
const UsuarioRemovido = require("./UsuarioRemovido");
const Video = require("./Video");
const VideoRemovido = require("./VideoRemovido");
const Comentario = require("./Comentario");
const Inscricao = require("./Inscricao");
const Notificacao = require("./Notificacao");
const ReacaoComentario = require("./ReacaoComentario");
const ReacaoVideo = require("./ReacaoVideo");

//Definindo as associações

UsuarioRemovido.belongsTo(Usuario, {
	foreignKey: 'id_usuario',
	as: 'usuario'
});
Usuario.hasOne(UsuarioRemovido, { foreignKey: 'id_usuario' });

//Video
Video.belongsTo(Usuario, {
	foreignKey: 'id_usuario',
	as: 'usuario'
});
Usuario.hasMany(Video, { foreignKey: 'id_usuario', as: "videos" });


VideoRemovido.belongsTo(Video, {
	foreignKey: 'id_video',
	as: 'video'
});
Video.hasOne(VideoRemovido, { foreignKey: 'id_video' });

//Comentario
Comentario.belongsTo(Video, {
	foreignKey: 'id_video',
	as: 'video'
});
Video.hasMany(Comentario, { foreignKey: 'id_video', as: 'comentarios' });


Comentario.belongsTo(Usuario, {
	foreignKey: 'id_usuario',
	as: 'usuario'
});
Usuario.hasMany(Comentario, { foreignKey: 'id_usuario' });

//Inscricao
Inscricao.belongsTo(Usuario, {
	foreignKey: 'id_usuario_inscrito',
	as: "inscrito"
});
Inscricao.belongsTo(Usuario, {
	foreignKey: 'id_usuario_principal',
	as: "principal"
});
Usuario.hasMany(Inscricao, { as: "principal" });
Usuario.hasMany(Inscricao, { as: "inscrito" });

//Notificacao
Notificacao.belongsTo(Video, {
	foreignKey: 'id_video',
	as: 'video'
})
Video.hasMany(Notificacao, { foreignKey: 'id_video', });

Notificacao.belongsTo(Inscricao, {
	foreignKey: 'id_inscricao',
	as: 'inscricao'
})
Inscricao.hasMany(Notificacao, { foreignKey: 'id_inscricao', as: 'notificacoes' });

//ReacaoComentario
ReacaoComentario.belongsTo(Usuario, {
	foreignKey: 'id_usuario',
	as: 'usuario'
});
Usuario.hasMany(ReacaoComentario, { foreignKey: 'id_usuario', as: "reacoes_comentarios" });

ReacaoComentario.belongsTo(Comentario, {
	foreignKey: 'id_comentario',
	as: 'comentario'
});
Comentario.hasMany(ReacaoComentario, { foreignKey: 'id_comentario', as: "reacoes_comentarios" });

//ReacaoVideo
ReacaoVideo.belongsTo(Usuario, {
	foreignKey: 'id_usuario',
	as: 'usuario'
});
Usuario.hasMany(ReacaoVideo, { foreignKey: 'id_usuario', as: "reacoes_videos" });

ReacaoVideo.belongsTo(Video, {
	foreignKey: 'id_video',
	as: 'video'
});
Video.hasMany(ReacaoVideo, { foreignKey: 'id_video', as: "reacoes_videos" });

module.exports = {
	Usuario,
	UsuarioRemovido,
	Video,
	VideoRemovido,
	Comentario,
	Inscricao,
	Notificacao,
	ReacaoComentario,
	ReacaoVideo
}