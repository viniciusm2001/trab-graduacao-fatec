const Sequelize = require("sequelize");
const con = require("../config/conexao");
const Dt = require("../utils/DtUtils");

class Comentario extends Sequelize.Model { }

Comentario.init({
   id: {
      type: Sequelize.INTEGER,
      primaryKey: true,
      autoIncrement: true,
      allowNull: false
   },
   comentario: {
      type: Sequelize.STRING(9999),
      allowNull: false,
      validate: {
         len: {
            args: [3, 9999],
            msg: "No minimo 3 caracteres e no maximo 9999"
         }
      }
   },
   id_usuario: {
      type: Sequelize.INTEGER,
		allowNull: false
   },
   id_video: {
      type: Sequelize.INTEGER,
		allowNull: false
   },
   criado_em:{
      type:Sequelize.DATE,
		allowNull: false,
      get(){
         return Dt.padrao(this.getDataValue("criado_em"))
      }
   },
   is_editado:{
      type:Sequelize.BOOLEAN,
		allowNull: false
   }
},{
   createdAt: 'criado_em',
   updatedAt: false,
   timestamps: true,
   underscored: true,
   tableName: 'tbl_comentario',
   modelName:'comentario',
   sequelize: con
});

module.exports = Comentario;