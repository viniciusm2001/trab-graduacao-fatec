const Sequelize = require("sequelize");
const con = require("../config/conexao");

class Notificacao extends Sequelize.Model { }

Notificacao.init({
   id: {
      type: Sequelize.INTEGER,
      primaryKey: true,
      autoIncrement: true,
      allowNull: false
   },
   id_inscricao: {
      type: Sequelize.INTEGER,
		allowNull: false
   },
   id_video: {
      type: Sequelize.INTEGER,
		allowNull: false
   },
   leu: {
      type: Sequelize.BOOLEAN,
		allowNull: false
   }
},{
   timestamps: false,
   underscored: true,
   tableName: 'tbl_notificacao',
   modelName:'notificacao',
   sequelize: con
});

module.exports = Notificacao;