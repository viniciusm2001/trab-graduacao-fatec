const Sequelize = require("sequelize");
const con = require("../config/conexao");
const Dt = require("../utils/DtUtils");

class Video extends Sequelize.Model { }

Video.init({
   id: {
      type: Sequelize.INTEGER,
      primaryKey: true,
      autoIncrement: true,
      allowNull: false
   },
   titulo: {
      type: Sequelize.STRING(100),
      allowNull: false,
      validate: {
         len: {
            args: [3, 100],
            msg: "No minimo 3 caracteres e no maximo 100"
         }
      }
   },
   descricao: {
      type: Sequelize.STRING(5000),
      validate: {
         len: {
            args: [0, 5000],
            msg: "No maximo 5000 caracteres"
         }
      }
   },
   id_usuario: {
      type: Sequelize.INTEGER
   },
   visualizacoes: {
      type: Sequelize.INTEGER,
      allowNull: false
   },
   url_id:{
      type:Sequelize.STRING(30),
      allowNull: false,
		unique: true
   },
   url_thumbnail: {
      type: Sequelize.STRING(150)
   },
   duracao: {
      type: Sequelize.STRING(50)
   },
   status: {
      type: Sequelize.STRING(1000)
   },
   is_denunciado: {
      type: Sequelize.BOOLEAN,
      allowNull: false
   },
   is_privado: {
      type: Sequelize.BOOLEAN,
      allowNull: false
   },
   status_err: {
      type: Sequelize.BOOLEAN,
      allowNull: false
   },
   criado_em:{
      type:Sequelize.DATE,
		allowNull: false,
      get(){
         return Dt.padraoComHorasSemSeg(this.getDataValue("criado_em"))
      }
   }
},{
   scopes:{
      normal:{
         attributes: { 
            exclude: [
					'id',
					'is_privado',
					'status',
					'status_err',
					'id_usuario',
					'is_denunciado'
				] 
         }
      }
   },
   createdAt: 'criado_em',
   updatedAt: false,
   timestamps: true,
   underscored: true,
   tableName: 'tbl_video',
   modelName:'video',
   sequelize: con
});

module.exports = Video;