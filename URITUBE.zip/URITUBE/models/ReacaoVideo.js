const Sequelize = require("sequelize");
const con = require("../config/conexao");

class ReacaoVideo extends Sequelize.Model { }

ReacaoVideo.init({
   id: {
      type: Sequelize.INTEGER,
      primaryKey: true,
      autoIncrement: true,
      allowNull: false
   },
   gostei: {
      type: Sequelize.BOOLEAN,
      allowNull: false
   },
   id_video: {
      type: Sequelize.INTEGER,
      allowNull: false
   },
   id_usuario: {
      type: Sequelize.INTEGER,
      allowNull: false
   }
},{
   underscored: true,
   timestamps: false,
   tableName: 'tbl_reacao_video',
   modelName:'reacao_video',
   sequelize: con
});

module.exports = ReacaoVideo;