const Sequelize = require("sequelize");
const con = require("../config/conexao");
const Dt = require("../utils/DtUtils");

class Usuario extends Sequelize.Model { }

Usuario.init({
   id: {
      type: Sequelize.INTEGER,
      primaryKey: true,
      autoIncrement: true,
      allowNull: false
   },
   nome: {
      type: Sequelize.STRING(100),
      allowNull: false,
      validate: {
         len: {
            args: [3, 100],
            msg: "No minimo 3 caracteres e no maximo 100"
         }
      }
   },
   email: {
      type: Sequelize.STRING(150),
      allowNull: false,
		unique: true,
      validate: {
         isEmail: {
            args: true,
            msg: "Preencha com um e-mail válido"
         },
         len: {
            args: [3, 150],
            msg: "No minimo 3 caracteres e no maximo 150"
         }
      }
   },
   senha: {
      type: Sequelize.STRING(128),
      allowNull: false
   },
   url_id:{
      type:Sequelize.STRING(30),
      allowNull: false,
		unique: true,
      validate: {
         len: {
            args: [3, 30],
            msg: "No minimo 3 caracteres e no maximo 30"
         }
      }
   },
   url_foto: {
      type: Sequelize.STRING(150)
   },
   is_denunciado: {
      type: Sequelize.BOOLEAN,
      allowNull: false
   },
   is_admin: {
      type: Sequelize.BOOLEAN,
      allowNull: false
   },
   criado_em:{
      type:Sequelize.DATE,
		allowNull: false,
      get(){
         return Dt.padrao(this.getDataValue("criado_em"))
      }
   },
},{
   // defaultScope: {
   //    attributes: { 
   //       exclude: [
	// 			'id',
   //          'email',
   //          'senha',
   //          'is_denunciado',
   //          'is_admin'
   //       ] 
   //    }
   // },
   defaultScope: {
      attributes: { 
         exclude: [
				'id',
            'email',
            'senha',
            'is_denunciado',
            'is_admin'
         ] 
      }
   },
   scopes:{
		completo2:{},
      completo:{
         attributes: { 
            exclude: [
					'email',
					'senha',
					'is_denunciado'
				] 
         }
      },
      canal:{
         attributes: { 
            exclude: [
					'email',
					'senha',
					'is_denunciado',
					'is_admin'
				] 
         }
      }
   },
   createdAt: 'criado_em',
   //updatedAt: 'atualizado_em',
   updatedAt: false,
   timestamps: true,
   underscored: true,
   tableName: 'tbl_usuario',
   modelName:'usuario',
   sequelize: con
});

module.exports = Usuario;