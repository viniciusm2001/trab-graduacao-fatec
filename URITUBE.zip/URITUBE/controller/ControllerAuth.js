const Usuario = require("../models/Rel").Usuario;
const UsuarioRemovido = require("../models/Rel").UsuarioRemovido;
const Auth = require("../utils/JwtAuth");

class ControllerAuth{

   static logar(tipo, json_dados){

		return new Promise(async resolve => {
			
			let json = null;
			let status = 0;
			let { email, senha } = json_dados;

			try {
				let usuario = await Usuario.scope("completo").findOne({ where: { senha, email } })

				if(usuario){

					usuario = usuario.toJSON();

					if(await UsuarioRemovido.findOne({ where: { id_usuario: usuario.id } })){
						status = 423;
					} else {

						if(tipo == "admin" && !usuario.is_admin){
							console.log("Erro ao gerar token do usuario pois o mesmo não é admin");
							status = 401;
		
						} else {

							//let opcoes_token = { expiresIn: "24h" };
							let opcoes_token = {};
		
							if(tipo == "admin"){
								opcoes_token = {};
							}
							
							try{
								const token = await Auth.signToken({ usuario }, opcoes_token)

								usuario.id = undefined
								usuario.is_admin = undefined

								json = { token, usuario }
								status = 200

							} catch (err) {
								console.trace(err)
								status = 500
							}
						}
					}
					
				} else {
					status = 404
				}

			} catch (err) {
				console.trace(err)
				status = 500
			}

			resolve({ status, json });
			
		})
   }
}

module.exports = ControllerAuth;