const Comentario = require("../models/Rel").Comentario;
const ReacaoComentario = require("../models/Rel").ReacaoComentario;
const Utils = require("../utils/Utils");
const DtUtils = require("../utils/DtUtils");
const { QueryTypes } = require("sequelize")
const con = require("../config/conexao")

class ControllerComentario{
	
   static async criar(req, res){
		
		const { usuario } = req.dadosToken
		let { id_video, comentario } = req.body;

		try {
			const com = await Comentario.create({
				id_usuario: usuario.id,
				id_video,
				comentario,
				is_editado: false
			})
			
			res.status(201).json(com)

		} catch (err) {
			console.trace(err)
			res.status(400).json(Utils.errToJSON(err))
		}
   }
	
   static async editar(req, res){
		
		const { usuario } = req.dadosToken
		const { id_comentario } = req.params
		let { comentario } = req.body;

		try {
			const com = await Comentario.findOne({ 
				where: {
					id_usuario: usuario.id,
					id: id_comentario
				}
			})
			
			if(!com){
				throw "Comentário não encontrado, ou não pertence a você"
			} else {
				
				Object.assign(com, { comentario, is_editado: true })

				await com.save()

				res.status(200).end()
			}

		} catch (err) {
			console.trace(err)
			res.status(404).json(Utils.errToJSON(err))
		}
   }
	
   static async excluir(req, res){
		
		const { usuario } = req.dadosToken
		const { id_comentario } = req.params

		try {
			const com = await Comentario.findOne({ 
				where: {
					id_usuario: usuario.id,
					id: id_comentario
				}
			})
			
			if(!com){
				throw "Comentário não encontrado, ou não pertence a você"
			} else {

				await ReacaoComentario.destroy({
					where: {
						id_comentario
					}
				})
				
				await com.destroy()

				res.status(204).end()
			}

		} catch (err) {
			console.trace(err)
			res.status(404).json(Utils.errToJSON(err))
		}
   }
	
   static async buscar(req, res){
		
		const { usuario } = req.dadosToken
		let { url_id_video, offset } = req.params;

		try {
			const comentarios = await ControllerComentario.getComentarios(
				(usuario ? usuario.id : null),
				url_id_video,
				offset
			)
			
			res.status(200).json(comentarios)

		} catch (err) {
			console.trace(err)
			res.status(400).json(Utils.errToJSON(err))
		}
   }
	
   static async gostar(req, res){
		
		let json = null
		let status = 400
		const { usuario } = req.dadosToken
		let { id_comentario } = req.params;

		try {
			const reacao = await ReacaoComentario.findOne({ 
				where: { 
					id_comentario, 
					id_usuario: usuario.id
				}
			})

			if(!reacao) {
				await ReacaoComentario.create({
					id_comentario, 
					id_usuario: usuario.id,
					gostei: true
				})

				status = 201

			} else {
				if(!reacao.gostei){
					Object.assign(reacao, { gostei: true });
					await reacao.save()
				} else {
					await reacao.destroy()
				}

				status = 200
			}

		} catch (err) {
			console.trace(err)
			json = Utils.errToJSON(err)
		}

		json ? res.status(status).json(json) : res.status(status).end();
   }
	
   static async nGostar(req, res){
		
		let json = null
		let status = 400
		const { usuario } = req.dadosToken
		let { id_comentario } = req.params;

		try {
			const reacao = await ReacaoComentario.findOne({ 
				where: { 
					id_comentario, 
					id_usuario: usuario.id
				}
			})

			if(!reacao) {
				await ReacaoComentario.create({
					id_comentario, 
					id_usuario: usuario.id,
					gostei: false
				})

				status = 201

			} else {
				if(reacao.gostei){
					Object.assign(reacao, { gostei: false });
					await reacao.save()
				} else {
					await reacao.destroy()
				}

				status = 200
			}

		} catch (err) {
			console.trace(err)
			json = Utils.errToJSON(err)
		}

		json ? res.status(status).json(json) : res.status(status).end();
   }

	static async getComentarios(id_usuario, url_id_video, offset){
		const comentarios = await con.query(
		`SELECT t1.nome, t1.url_id, t1.url_foto, t2.comentario,
		t2.is_editado, t2.id, t2.criado_em,
		reacoes.gostei AS reacao_usuario, 
		SUM(t3.gostei = 1) AS num_gostei,
		SUM(t3.gostei = 0) AS num_n_gostei
		FROM tbl_usuario AS t1
		INNER JOIN tbl_comentario as t2 ON t2.id_usuario=t1.id
		LEFT JOIN 
			(
				SELECT 
				t1.id AS id_comentario,
				t2.gostei
				FROM tbl_comentario AS t1
				LEFT JOIN tbl_reacao_comentario AS t2 ON t2.id_comentario=t1.id
				WHERE t2.id_usuario=${id_usuario ? id_usuario : 0}
			) AS reacoes ON reacoes.id_comentario=t2.id 
		INNER JOIN tbl_video AS t4 ON t4.id = t2.id_video
		LEFT JOIN tbl_reacao_comentario AS t3 ON t3.id_comentario=t2.id
		WHERE t4.url_id="${url_id_video}"
		GROUP BY t2.id ORDER BY t2.criado_em DESC
		LIMIT 10 OFFSET ${offset * 10};`,
		{ type: QueryTypes.SELECT });
		
		for(let i = 0; i < comentarios.length; i++){
			comentarios[i].criado_em = DtUtils.padrao(
				comentarios[i].criado_em
			)
		}
		
		return comentarios
	}
}

module.exports = ControllerComentario;