const Usuario = require("../models/Rel").Usuario;
const Video = require("../models/Rel").Video;
const UsuarioRemovido = require("../models/Rel").UsuarioRemovido;
const VideoRemovido = require("../models/Rel").VideoRemovido;
const Utils = require("../utils/Utils");
const controllerVideo = require("../controller/ControllerVideo");
const Sequelize = require("sequelize")
const { QueryTypes, Op } = require("sequelize")
const con = require("../config/conexao")
const { salvarImagem } = require("../utils/ProcVideo");
const Auth = require("../utils/JwtAuth");
const FsUtils = require("../utils/FsUtils");

class ControllerUsuario{

	static isUrlIdUnico(url_id, id_usuario = null){
		return new Promise(async resolve => {
			if(!id_usuario){
				await Usuario.findOne({ where: { url_id } }) ? resolve(false) : resolve(true)

			} else {
				await Usuario.findOne({ 
					where: { 
						url_id,
						id: { [Op.ne]: id_usuario }
					} 
				}) ? 
					resolve(false) : resolve(true)
			}
		})
	}

	static isEmailUnico(email, id_usuario = null){
		return new Promise(async resolve => {
			if(!id_usuario){
				await Usuario.findOne({ where: { email } }) ? resolve(false) : resolve(true)
			} else {
				await Usuario.findOne({ 
					where: { 
						email,
						id: { [Op.ne]: id_usuario }
					} 
				}) ? 
					resolve(false) : resolve(true)
			}

		})
	}
	
   static async criar(req, res){
			
			let json = null;
			let status = 400
			
			let { nome, url_id, email, senha } = req.body;

			try {

				if(!(await ControllerUsuario.isUrlIdUnico(url_id))){
					throw "Esta url já está sendo usanda por outro canal no momento"

				} else {

					if(!(await ControllerUsuario.isEmailUnico(email))){
						throw "Este email já está sendo usando no momento"
	
					} else {
						let novo_usuario = await Usuario.create({ nome, url_id, email, senha, url_foto: null,
							is_denunciado: false, is_admin: false })
						
						json = Utils.jsonIncOrRem("remover", 
							["is_admin", "is_denunciado", "senha", "email"],
							novo_usuario.toJSON())

						status = 200
					}		
				}
				
			} catch (err) {
				console.trace(err)
				json = Utils.errToJSON(err)
			}
			
			json ? res.status(status).json(json) : res.status(status).end();
		
   }
	
   static async editar(req, res){
			
			let json = null;
			let status = 400;
			let ft_antiga = null;
			
			const { usuario: usr } = req.dadosToken
			let { nome, url_id, novo_email, senha, nova_senha, foto_base64 } = req.body;

			try {
				if(!senha){
					throw "Por favor digite sua senha atual"
				}

				let usuario = await Usuario.scope("completo2").findOne({ where: { id: usr.id, senha } })

				if(!usuario){
					throw "Sua senha atual está incorreta"
				}

				if(novo_email){
					if(usuario.email == novo_email){
						throw "Email cadastrado e email novo são iguais"
					}

					if(!(await ControllerUsuario.isEmailUnico(novo_email))){
						throw "Este email já está sendo usando no momento"
					}
				}

				if(!(await ControllerUsuario.isUrlIdUnico(url_id, usuario.id))){
					throw "Esta url já está sendo usanda por outro canal no momento"

				} else {

					let json_editar = { nome, url_id }
					
					if(foto_base64){
						let url_foto = "";
	
						url_foto = await salvarImagem(foto_base64, "perfil")
	
						json_editar.url_foto = url_foto

						if(usuario.url_foto){
							ft_antiga = usuario.url_foto
						}
					}

					if(nova_senha){
						json_editar.senha = nova_senha
					}

					if(novo_email){
						json_editar.email = novo_email
					}
	
					Object.assign(usuario, json_editar)
	
					await usuario.save()
					
					ft_antiga ? await FsUtils.deletarArquivo("." + ft_antiga) : null;
					
					usuario = Utils.jsonIncOrRem("remover", 
						["is_denunciado", "senha", "email"],
						usuario.toJSON())

					const opcoes_token = {};

					const token = await Auth.signToken({ usuario }, opcoes_token)

					usuario.id = undefined
					usuario.is_admin = undefined

					json = { token, usuario }

					status = 200
				}
				
			} catch (err) {
				console.trace(err)
				json = Utils.errToJSON(err)
			}
			
			json ? res.status(status).json(json) : res.status(status).end();
		
   }

	static async deletar (req, res){
		
		let json = null
		let status = 400
		const { usuario: usr } = req.dadosToken
		const senha = req.headers['senha'];

		try {
			if(!senha){
				throw "Por favor digite sua senha atual"
			}
			
			let usuario = await Usuario.scope("completo2").findOne({ where: { id: usr.id, senha } })

			if(!usuario){
				throw "Sua senha atual está incorreta"
			}

			await ControllerUsuario.removerUsuario(usuario, "Canal removido pelo proprio usuario");
			status = 204

		} catch(err) {
			console.trace(err)
			json = Utils.errToJSON(err)
		}

		json ? res.status(status).json(json) : res.status(status).end();
	}

	static async getInfoCanal (req, res){
		
		let json = null
		let status = 404
		const { url_id } = req.params
		const { usuario: usr } = req.dadosToken

		try {
			let usuario = await Usuario.scope("canal").findOne({ where: { url_id } })

			if(!usuario){
				throw "Usuario não encontrado"
			}
			
			usuario = usuario.toJSON()

			if(await UsuarioRemovido.findOne({ where: { id_usuario: usuario.id } })){
				throw "Usuario removido"
			}
			
			usuario.id = undefined

			Object.assign(usuario, await ControllerUsuario.getNumInscritos(
				(usr ? usr.id : null),
				url_id,
			))

			Object.assign(usuario, await ControllerUsuario.nVideos(url_id))

			json = usuario
			status = 200

		} catch(err) {
			console.trace(err)
			json = Utils.errToJSON(err)
		}
		
		json ? res.status(status).json(json) : res.status(status).end();
	}

	static async removerUsuario(usuario, razao) {

		await UsuarioRemovido.create({ id_usuario: usuario.id, razao })

		const videos = await Video.findAll({ 
			where: {
				id_usuario: usuario.id,
				[Op.and]: Sequelize.literal("video_removido.id IS NULL")
			}, 
			include: { model: VideoRemovido, required: false, where: { id: null } } 
		})

		for(let i = 0; i < videos.length; i++){
			await controllerVideo.removerVideo(videos[i], "Canal ao qual pertencia foi excluido", true)
		}

		await con.query(`
		DELETE rc, rv
		FROM tbl_usuario AS u
		INNER JOIN tbl_reacao_video AS rv ON rv.id_usuario=u.id
		INNER JOIN tbl_reacao_comentario AS rc ON rc.id_usuario=u.id
		WHERE u.id="${usuario.id}";`,
		{ type: QueryTypes.DELETE });

		await con.query(`
		DELETE rc
		FROM tbl_usuario AS u
		INNER JOIN tbl_comentario AS c ON c.id_usuario=u.id
		INNER JOIN tbl_reacao_comentario AS rc ON rc.id_comentario=c.id
		WHERE u.id="${usuario.id}";`,
		{ type: QueryTypes.DELETE });

		await con.query(`
		DELETE c 
		FROM tbl_usuario AS u
		INNER JOIN tbl_comentario AS c ON u.id=c.id_usuario
		WHERE u.id="${usuario.id}";`,
		{ type: QueryTypes.DELETE });

		return
	}

	static async getNumInscritos(id_usuario, url_id){
		const usuario = await con.query(`
		SELECT
		(
			SELECT
			COUNT(*) AS n_linhas
			FROM tbl_usuario AS t1 
			LEFT JOIN tbl_inscricao AS t2 ON t1.id=t2.id_usuario_principal 
			WHERE t1.url_id="${url_id}"
			AND t2.id_usuario_inscrito=${id_usuario} 
			LIMIT 1
		) AS is_inscrito,
		COUNT(t2.id_usuario_inscrito) AS "n_inscritos"
		FROM tbl_usuario AS t1 
		LEFT JOIN tbl_inscricao AS t2 ON t1.id=t2.id_usuario_principal 
		WHERE t1.url_id="${url_id}" GROUP BY t1.id;`,
		{ type: QueryTypes.SELECT });

		return usuario[0]
	}

	static async nVideos(url_id){
		const video = await con.query(`
		SELECT COUNT(v.id) AS n_videos
		FROM tbl_video AS v
		INNER JOIN tbl_usuario AS u ON u.id=v.id_usuario
		LEFT JOIN tbl_video_removido AS vr ON vr.id_video=v.id
		WHERE u.url_id="${url_id}" AND vr.id IS NULL 
		AND v.status = "";`,
		{ type: QueryTypes.SELECT });

		return video[0]
	}
}

module.exports = ControllerUsuario;