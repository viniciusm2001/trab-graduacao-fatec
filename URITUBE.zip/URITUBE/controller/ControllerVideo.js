const Utils = require("../utils/Utils");
const Video = require("../models/Rel").Video
const VideoRemovido = require("../models/Rel").VideoRemovido
const Usuario = require("../models/Rel").Usuario
const Auth = require("../utils/JwtAuth");
const multer = require("multer");
const path = require("path");
const FsUtils = require("../utils/FsUtils")
const { QueryTypes } = require("sequelize")
const con = require("../config/conexao")
const ReacaoVideo = require("../models/Rel").ReacaoVideo;
const Sequelize = require("sequelize")
const DtUtils = require("../utils/DtUtils");
const { salvarImagem } = require("../utils/ProcVideo");
const { Op } = Sequelize

class ControllerVideo{
	
	static getUpload(nome_input, caminho_pasta = null){
	
		return new Promise(resolve => {
	
			const checar_arquivo = (file, cb) => {
				
				//Formatos permitidos
				let arquivos_permitidos = / /;
	
				//Mimetypes permitidos
				let mimetypes_permitidos = / /;
	
				arquivos_permitidos = /avi|mp4|mov|qt/;
				mimetypes_permitidos = /avi|divx|msvideo|video\/mp4|video\/quicktime/;
	
				//Checa a extensão
				const extensao = arquivos_permitidos.test(path.extname(file.originalname).toLowerCase());
	
				//Checa a mimetype (tipo do arquivo)
				const mimetype = mimetypes_permitidos.test(file.mimetype)
	
				extensao && mimetype ? cb(null, true) : 
					cb("Somente videos no formato mp4, avi e mov são permitdos", false)
			}
	
			const criar_pasta_de_destino = async (file, cb) => {
	
				while(true){
					
					this.url_id = Utils.gerarId()
					this.caminho = "./videos/" + this.url_id + "/";

					if(!(await Video.findOne({ where: { url_id: this.url_id } }))){

						try {
							await FsUtils.criarPasta(this.caminho)
							cb(null, this.caminho)
						} catch(err) {
							console.trace(err)
							cb("Erro ao criar pasta", false)	
						}

						break
					}
				}
			}
	
			//Seta o Storage Engine
			const storage = multer.diskStorage({
				// destination: "./public/uploads/",
				destination: (req, file, cb) => {
					criar_pasta_de_destino(file, cb)
				},
				filename: (req, file, cb) => {
					cb(null, "arquivo-original.video")
				}
			})
	
			const upload = multer({
				storage,
				limits:{
					fileSize: 2147483648 //2GB
				},
				fileFilter: (req, file, cb) => {
					checar_arquivo(file, cb)
				}
			}).single(nome_input)
			//}).single("video_upload")
	
			resolve(upload)
		})
	}

   static async enviar (req, res){

		if(parseInt(req.headers['content-length']) > 2147483648){
			res.status(400).
				json(Utils.setErrJSON("Tamanho máximo de 2GB por video"))
		} else {
	
			const upload = await ControllerVideo.getUpload("video_upload")
	
			upload(req, res, async (err) => {
				if(err){
					console.trace(err);
					res.status(400).json(Utils.errToJSON(err))
				} else {

					let json_envio = { url_id: ControllerVideo.url_id }
					
					const token = await Auth.signToken({ url_id: json_envio.url_id }, { expiresIn: "24h" })
					
					json_envio.token = token
					
					res.status(201).json(json_envio)
				}
			})
		}
	}


	static async addVideoInfo(req, res){
		let json = null
		let status = 0

		const { usuario, url_id: url_id_token } = req.dadosToken

		const { titulo, descricao, is_privado, url_id } = req.body

		try {

			if(url_id_token){
				if(url_id_token !== url_id){
					throw "url_id presente no token e no JSON de envio são diferentes"
				}
			}
			
			if(!(await Video.findOne({where: { url_id }}))){
				
				if(await FsUtils.pastaOuArqExiste("./videos/" + url_id + "/")){
					
					await Video.create({ url_id, titulo,
						is_privado: usuario ? is_privado : true,
						descricao: descricao ? descricao : null,
						visualizacoes: 0, is_denunciado: false,
						status: null, status_err: false, url_thumbnail: null,
						id_usuario: usuario ? usuario.id : null, duracao: null })
						
					status = 201

				} else {
					throw "Video não enviado ao servidor (inexistente)"
				}

			} else {
				throw "Este video já existe, então não é possivel sobrescreve-lo"
			}

		} catch(err){
			console.trace(err)
			json = Utils.errToJSON(err)
			status = 400
		}
		
		json ? res.status(status).json(json) : res.status(status).end();
	}

	static async getStatus(req, res){
		
		let json = null
		let status = 400

		const { usuario, url_id: url_id_token } = req.dadosToken
		const url_id = req.params.url_id

		try {

			if(url_id_token){
				if(url_id_token !== url_id){
					throw "url_id presente no token e na url de envio são diferentes"
				}
			}

			if(!usuario){
				let json_busca = {
					where: {
						url_id
					},
					attributes:["status"]
				}

				const video = await Video.findOne(json_busca)

				if(!video){
					status = 404
					throw "Video inexistente"
				}
				
				json = video
				status = 200

			} else {

				const video = await ControllerVideo.getStatusMeuVideo(usuario.id, url_id)

				if(!video){
					throw "Você não enviou este video, logo não pode visualizar seu progresso"
				}

				json = video
				status = 200
			}

		} catch(err) {
			console.trace(err)
			json = Utils.errToJSON(err)
		}

		json ? res.status(status).json(json) : res.status(status).end();
	}

	static async deletarVideo(req, res){
		
		let json = null
		let status = 400

		const { usuario } = req.dadosToken
		const url_id = req.params.url_id

		try {

			const video = await Video.findOne({ 
				where: {
					id_usuario: usuario.id,
					url_id,
					[Op.and]: Sequelize.literal("video_removido.id IS NULL")
				}, 
				include: { model: VideoRemovido, required: false } 
			})

			if(!video){
				status = 404
			} else {
				await ControllerVideo.removerVideo(video, "Removido pelo usuario", true)
				status = 204
			}

		} catch(err) {
			console.trace(err)
			json = Utils.errToJSON(err)
		}

		json ? res.status(status).json(json) : res.status(status).end();
	}

	static async getRecomendados (req, res){
		const { url_id, offset } =  req.params

		let json = null
		let status = 404

		try {
			const video = await Video.findOne({ where: { url_id }})

			if(video) {
				const palavras_titulo = video.titulo.split(" ");
				const palavras_descricao = video.descricao ? video.descricao.split(" ") : [];

				let queries = []

				for(let i = 0; i < palavras_titulo.length; i++){
					queries.push(Sequelize.where(Sequelize.col("titulo"), "LIKE", "%" + palavras_titulo[i] + "%"))	
					queries.push(Sequelize.where(Sequelize.col("descricao"), "LIKE", "%" + palavras_titulo[i] + "%"))	
				}

				for(let i = 0; i < palavras_descricao.length; i++){
					queries.push(Sequelize.where(Sequelize.col("titulo"), "LIKE", "%" + palavras_descricao[i] + "%"))	
					queries.push(Sequelize.where(Sequelize.col("descricao"), "LIKE", "%" + palavras_descricao[i] + "%"))
				}

				const where = {
					[Op.or]: queries,
					[Op.and]: [
						{ is_privado: false },
						{ status: "" },
						{ url_id: { [Op.ne]: url_id } },
						{ id_usuario: { [Op.ne]: null } }, 
						Sequelize.literal("video_removido.id IS NULL")
					]
				}

				const videos = await Video.scope("normal").findAll({ 
					where, 
					order: Sequelize.literal('rand()'),
					include: [{ model: Usuario, as: "usuario" }, 
					{ model: VideoRemovido, required: false }],
					limit: 20, offset: offset * 20 })
				
				status = 200
				json = videos
			}

		} catch (err) {
			console.trace(err)
			json = Utils.errToJSON(err)
		}

		json ? res.status(status).json(json) : res.status(status).end();
	}

	static async getPaginaInicial (req, res){
		const { tipo, offset } =  req.params

		let json = null
		let status = 404
		let order = [["visualizacoes", "DESC"]]

		try {

			const where = {
				is_privado: false,
				status: "" ,
				id_usuario: { [Op.ne]: null },
				[Op.and]: Sequelize.literal("video_removido.id IS NULL")
			}

			switch (tipo) {
				case "populares-hoje":
					where.criado_em = { [Op.gt]: new Date(Date.now() - (24 * 60 * 60 * 1000)) } 
					break;

				case "populares-esta-semana":
					where.criado_em = { [Op.gt]: new Date(Date.now() - (7 * 24 * 60 * 60 * 1000)) } 
					break;

				case "enviados-recentemente":
					order = [["criado_em", "DESC"]]
					break;
			
				default:
					throw "Url incorreta"
			}

			const videos = await Video.scope("normal").findAll({ 
				where, 
				order,
				include: [{ model: Usuario, as: "usuario" }, 
				{ model: VideoRemovido, as: "video_removido", required: false}], 
				limit: 20, offset: offset * 20 })
			
			status = 200
			json = videos

		} catch (err) {
			console.trace(err)
			json = Utils.errToJSON(err)
		}

		json ? res.status(status).json(json) : res.status(status).end();
	}

	static async getResultadosPesquisa (req, res){
		const { termo_pesquisa, offset, order_by } =  req.params

		let json = null
		let status = 400
		let order = [[]];

		try {
			const palavras_pesquisa = termo_pesquisa.split(" ");

			let queries = []

			for(let i = 0; i < palavras_pesquisa.length; i++){
				queries.push(Sequelize.where(Sequelize.col("titulo"), "LIKE", "%" + palavras_pesquisa[i] + "%"))	
				queries.push(Sequelize.where(Sequelize.col("descricao"), "LIKE", "%" + palavras_pesquisa[i] + "%"))	
			}

			const where = {
				[Op.or]: queries,
				is_privado: false,
				status: "" ,
				id_usuario: { [Op.ne]: null },
				[Op.and]: Sequelize.literal("video_removido.id IS NULL")
			}

			switch (order_by) {
				case "mais-visualizacoes":
					order = [["visualizacoes", "DESC"]]
					break;

				case "menos-visualizacoes":
					order = [["visualizacoes", "ASC"]]
					break;

				case "mais-antigo":
					order = [["criado_em", "ASC"]]
					break;

				case "mais-recente":
					order = [["criado_em", "DESC"]]
					break;
			
				default:
					throw "Url incorreta"
			}

			const videos = await Video.scope("normal").findAll({ 
				where, 
				order,
				include: [{ model: Usuario, as: "usuario" }, 
				{ model: VideoRemovido, required: false }],
				limit: 20, offset: offset * 20 })
			
			status = 200
			json = videos

		} catch (err) {
			console.trace(err)
			json = Utils.errToJSON(err)
		}

		json ? res.status(status).json(json) : res.status(status).end();
	}

	static async getGerenciamento (req, res){
		const { usuario } = req.dadosToken
		const { offset, order_by } =  req.params

		let json = null
		let status = 400
		let videos = [];

		try {
			switch (order_by) {
				case "mais-visualizacoes":
					videos = await ControllerVideo.getMeusVideos(
						usuario.id, "visualizacoes", "DESC", offset
					)
					break;

				case "menos-visualizacoes":
					videos = await ControllerVideo.getMeusVideos(
						usuario.id, "visualizacoes", "ASC", offset
					)
					break;

				case "mais-antigo":
					videos = await ControllerVideo.getMeusVideos(
						usuario.id, "criado_em", "ASC", offset
					)
					break;

				case "mais-recente":
					videos = await ControllerVideo.getMeusVideos(
						usuario.id, "criado_em", "DESC", offset
					)
					break;
			
				default:
					throw "Url incorreta"
			}
			
			status = 200
			json = videos

		} catch (err) {
			console.trace(err)
			json = Utils.errToJSON(err)
		}

		json ? res.status(status).json(json) : res.status(status).end();
	}

	static async getCanal (req, res){
		const { url_id, offset, order_by } =  req.params

		let json = null
		let status = 400
		let videos = [];

		try {
			switch (order_by) {
				case "mais-visualizacoes":
					videos = await ControllerVideo.getVideosCanal(
						url_id, "visualizacoes", "DESC", offset
					)
					break;

				case "menos-visualizacoes":
					videos = await ControllerVideo.getVideosCanal(
						url_id, "visualizacoes", "ASC", offset
					)
					break;

				case "mais-antigo":
					videos = await ControllerVideo.getVideosCanal(
						url_id, "criado_em", "ASC", offset
					)
					break;

				case "mais-recente":
					videos = await ControllerVideo.getVideosCanal(
						url_id, "criado_em", "DESC", offset
					)
					break;
			
				default:
					throw "Url incorreta"
			}
			
			status = 200
			json = videos

		} catch (err) {
			console.trace(err)
			json = Utils.errToJSON(err)
		}

		json ? res.status(status).json(json) : res.status(status).end();
	}

	static async getVideoParaAssitir (req, res) {

		const { usuario } = req.dadosToken
		const { url_id } = req.params

		let json = null
		let status = 404

		try {
			let video = await Video.findOne({ 
				where: { url_id },
				include: [{ model: VideoRemovido, required: false },
				{model: Usuario, required: false, as: "usuario" }], 
				attributes: { exclude: ["id_usuario", "is_denunciado", "is_privado"] } 
			})

			if(!video){
				throw "Video não encontrado"

			} else {
				if(video.video_removido){
					throw "Video removido.\nRazão: " + video.video_removido.razao

				} else {
					if(video.status_err || 
						video.status !== "") {
						throw "Video indisponivel"

					} else {
						const arquivos = await FsUtils.getArquivosPasta("./videos/" + url_id + "/arquivos");
						let qualidades = []

						for(let i = 0; i < arquivos.length; i++){
							if(arquivos[i].includes("mp4")){
								qualidades.push(Utils.copiarStringAteChar(arquivos[i], "."))
							}
						}

						video.visualizacoes += 1

						video.save()

						video = video.toJSON()

						video = Utils.jsonIncOrRem("remover", [ 
							"video_removido", "status", "status_err"], video)
						
						Object.assign(video, await ControllerVideo.getNumReacoes(
							(usuario ? usuario.id : null),
							url_id,
						))

						if(!video.usuario.nome){
							video.usuario = null
						} else {
							Object.assign(video.usuario, await ControllerVideo.getNumInscritos(
								(usuario ? usuario.id : null),
								video.usuario.url_id,
							))
						}
						
						video.qualidades = qualidades
						
						json = video
						status = 200
					}
				}
			}

		} catch (err){
			//console.error(err)
			json = Utils.errToJSON(err)
		}

		json ? res.status(status).json(json) : res.status(status).end();
	}

	static async getNumInscritos(id_usuario, url_id){
		const usuario = await con.query(`
		SELECT
		(
			SELECT
			COUNT(*) AS n_linhas
			FROM tbl_usuario AS t1 
			LEFT JOIN tbl_inscricao AS t2 ON t1.id=t2.id_usuario_principal 
			WHERE t1.url_id="${url_id}"
			AND t2.id_usuario_inscrito=${id_usuario} 
			LIMIT 1
		) AS is_inscrito,
		COUNT(t2.id_usuario_inscrito) AS "n_inscritos"
		FROM tbl_usuario AS t1 
		LEFT JOIN tbl_inscricao AS t2 ON t1.id=t2.id_usuario_principal 
		WHERE t1.url_id="${url_id}" GROUP BY t1.id;`,
		{ type: QueryTypes.SELECT });

		return usuario[0]
	}

	static async getVideoArquivo(req, res){

		const { url_id, qualidade } = req.params

		if(req.params.nome_arquivo){
			res.setHeader("Content-Type", "application/octet-stream");
			res.setHeader('Content-Disposition', 'attachment;filename=' + 
				req.params.nome_arquivo + " (" + qualidade + ").mp4");
		}

		const caminho_video = "videos/" + url_id + "/arquivos/" + qualidade + ".mp4"

		if(!(await FsUtils.pastaOuArqExiste("./" + caminho_video))){

			res.status(404).json(Utils.errToJSON("Arquivo inexistente"))

		} else {
			res.sendFile(path.join(process.cwd(), caminho_video));
		}
	}

	static async getVideoThumbnail(req, res){

		const { url_id } = req.params

		const caminho_thumb = "videos/" + url_id + "/arquivos/thumbnail.jpg"

		if(!(await FsUtils.pastaOuArqExiste("./" + caminho_thumb))){

			res.status(404).json(Utils.errToJSON("Thumbnail inexistente"))

		} else {
			res.sendFile(path.join(process.cwd(), caminho_thumb));
		}
	}
	
   static async gostar(req, res){
		
		let json = null
		let status = 400
		const { usuario } = req.dadosToken
		let { id_video } = req.params;

		try {
			const reacao = await ReacaoVideo.findOne({ 
				where: { 
					id_video, 
					id_usuario: usuario.id
				}
			})

			if(!reacao) {
				await ReacaoVideo.create({
					id_video, 
					id_usuario: usuario.id,
					gostei: true
				})

				status = 201

			} else {
				if(!reacao.gostei){
					Object.assign(reacao, { gostei: true });
					await reacao.save()
				} else {
					await reacao.destroy()
				}

				status = 200
			}

		} catch (err) {
			console.trace(err)
			json = Utils.errToJSON(err)
		}

		json ? res.status(status).json(json) : res.status(status).end();
   }
	
   static async nGostar(req, res){
		
		let json = null
		let status = 400
		const { usuario } = req.dadosToken
		let { id_video } = req.params;

		try {
			const reacao = await ReacaoVideo.findOne({ 
				where: { 
					id_video, 
					id_usuario: usuario.id
				}
			})

			if(!reacao) {
				await ReacaoVideo.create({
					id_video, 
					id_usuario: usuario.id,
					gostei: false
				})

				status = 201

			} else {
				if(reacao.gostei){
					Object.assign(reacao, { gostei: false });
					await reacao.save()
				} else {
					await reacao.destroy()
				}

				status = 200
			}

		} catch (err) {
			console.trace(err)
			json = Utils.errToJSON(err)
		}

		json ? res.status(status).json(json) : res.status(status).end();
   }
	
   static async editar(req, res){
		
		const { usuario } = req.dadosToken
		const { url_id } = req.params
		let { titulo, descricao, is_privado, thumbnail_base64 } = req.body;
		let ft_antiga = null;

		try {
			const video = await Video.findOne({ 
				where: {
					id_usuario: usuario.id,
					url_id
				}
			})
			
			if(!video){
				throw "Video não encontrado, ou não pertence a você"
			} else {

				let json_editar = { titulo, descricao, is_privado }

				if(thumbnail_base64){
					let url_thumbnail = "";

					url_thumbnail = await salvarImagem(thumbnail_base64, "thumbnail")

					json_editar.url_thumbnail = url_thumbnail

					if(video.url_thumbnail){
						ft_antiga = video.url_thumbnail
					}
				}

				Object.assign(video, json_editar)

				await video.save()

				ft_antiga ? await FsUtils.deletarArquivo("." + ft_antiga) : null;

				res.status(200).json(
					Utils.jsonIncOrRem("incluir", 
						["url_id", "url_thumbnail", "titulo", "descricao", "is_privado"], 
						video.toJSON()
					)
				)
			}

		} catch (err) {
			console.trace(err)
			res.status(400).json(Utils.errToJSON(err))
		}
   }
	
	static async removerVideo(video, razao, completo = false){

		if(razao){
			await VideoRemovido.create({ id_video: video.id, razao })
		}

		if(video.url_thumbnail){
			await FsUtils.deletarArquivo("." + video.url_thumbnail);
		}
		
		await FsUtils.criarPasta("./videos/" + video.url_id + "/arquivos")
		await FsUtils.deletarPastaEArquivosDentro("./videos/" + video.url_id + "/arquivos")
		await FsUtils.deletarPastaEArquivosDentro("./videos/" + video.url_id + "/")

		if(completo){

			await con.query(`
			DELETE rc, rv
			FROM tbl_video AS v
			INNER JOIN tbl_reacao_video AS rv ON v.id=rv.id_video
			INNER JOIN tbl_comentario AS c ON c.id_video=v.id
			INNER JOIN tbl_reacao_comentario AS rc ON rc.id_comentario=c.id
			WHERE v.url_id="${video.url_id}";`,
			{ type: QueryTypes.DELETE });

			await con.query(`
			DELETE c 
			FROM tbl_video AS v
			INNER JOIN tbl_comentario AS c ON c.id_video=v.id
			WHERE v.url_id="${video.url_id}";`,
			{ type: QueryTypes.DELETE });
		}

		return
	}

	static async getNumReacoes(id_usuario, url_id){
		const reacoes = await con.query(`
		SELECT 
			(
				SELECT
				rv.gostei
				FROM tbl_video AS v
				INNER JOIN tbl_reacao_video AS rv ON rv.id_video = v.id
				AND v.url_id="${url_id}"
				AND rv.id_usuario=${id_usuario}
				GROUP BY v.url_id
				LIMIT 1
			) AS reacao_usuario,
		SUM(rv.gostei = 1) AS gostei,
		SUM(rv.gostei = 0) AS n_gostei
		FROM tbl_video AS v
		INNER JOIN tbl_reacao_video AS rv ON rv.id_video = v.id
		INNER JOIN tbl_usuario AS u ON rv.id_usuario = u.id
		AND v.url_id="${url_id}"
		GROUP BY v.id;`,
		{ type: QueryTypes.SELECT });
		
		return reacoes[0]
	}

	static async getMeusVideos(id_usuario, order_by, sort, offset){
		const videos = await con.query(`
		SELECT v.titulo, v.url_id, v.visualizacoes, v.is_privado, v.duracao,
		v.descricao, v.url_thumbnail, v.status, v.status_err, v.criado_em,
		c.num_comentarios AS num_comentarios,
		SUM(rv.gostei = 1) AS gostei,
		SUM(rv.gostei = 0) AS n_gostei
		FROM tbl_video AS v
		LEFT JOIN
		(
			SELECT
			COUNT(cm.id) AS num_comentarios,
			cm.id_video
			FROM tbl_comentario AS cm
			INNER JOIN tbl_video AS vd ON cm.id_video=vd.id
			GROUP BY vd.id
		) AS c ON c.id_video=v.id
		LEFT JOIN tbl_reacao_video AS rv ON rv.id_video = v.id
		INNER JOIN tbl_usuario AS u ON v.id_usuario = u.id
		LEFT JOIN tbl_video_removido AS vr ON vr.id_video=v.id
		WHERE vr.id_video IS NULL
		AND u.id=${id_usuario}
		GROUP BY v.id ORDER BY v.${order_by} ${sort}
		LIMIT 10 OFFSET ${offset * 10};`,
		{ type: QueryTypes.SELECT });
		
		for(let i = 0; i < videos.length; i++){
			videos[i].criado_em = DtUtils.padraoComHorasSemSeg(
				videos[i].criado_em
			)
		}
		
		return videos
	}

	static async getVideosCanal(url_id, order_by, sort, offset){
		const videos = await con.query(`
		SELECT v.url_id, v.url_thumbnail, v.duracao, v.titulo,
		v.visualizacoes, v.criado_em
		FROM tbl_video AS v
		INNER JOIN tbl_usuario AS u ON u.id=v.id_usuario
		LEFT JOIN tbl_video_removido AS vr ON vr.id_video=v.id
		WHERE u.url_id="${url_id}" AND vr.id IS NULL 
		AND v.status = ""
		GROUP BY v.id ORDER BY v.${order_by} ${sort}
		LIMIT 10 OFFSET ${offset * 10};`,
		{ type: QueryTypes.SELECT });
		
		for(let i = 0; i < videos.length; i++){
			videos[i].criado_em = DtUtils.padraoComHorasSemSeg(
				videos[i].criado_em
			)
		}
		
		return videos
	}

	static async getStatusMeuVideo(id_usuario, url_id){
		let videos = await con.query(`
		SELECT v.duracao, v.url_thumbnail, v.status, v.status_err
		FROM tbl_video AS v
		WHERE v.id_usuario=${id_usuario} AND v.url_id="${url_id}"
		LIMIT 1;`,
		{ type: QueryTypes.SELECT });

		return videos[0] ? videos[0] : null
	}
}

module.exports = ControllerVideo;