-- ==================================================================================================== --
-- ========== DELETA O BANCO SE HÁ UMA VERSÃO ANTIGA DO MESMO ========== --
DROP DATABASE IF EXISTS db_uritube;

-- ==================================================================================================== --
-- ========== CRIANDO O BANCO DE DADOS ========== --
CREATE DATABASE db_uritube;

-- ==================================================================================================== --
-- ========== ENTRANDO NO BANCO RECEM CRIADO PARA CRIAR AS TABELAS ========== --
USE db_uritube;

CREATE TABLE tbl_usuario (
	id INT NOT NULL PRIMARY KEY AUTO_INCREMENT,
	url_id VARCHAR(30) NOT NULL UNIQUE,
	nome VARCHAR(100) NOT NULL,
	senha VARCHAR(128) NOT NULL,
	email VARCHAR(150) NOT NULL UNIQUE,
	url_foto VARCHAR(150) UNIQUE,
	is_denunciado TINYINT NOT NULL,
	is_admin TINYINT NOT NULL,
	criado_em TIMESTAMP NOT NULL
);

INSERT INTO tbl_usuario VALUES (
	0, 
	"canal-do-vinicius", 
	"Vinicius Morais", 
	"ba3253876aed6bc22d4a6ff53d8406c6ad864195ed144ab5c87621b6c233b548baeae6956df346ec8c17f5ea10f35ee3cbc514797ed7ddd3145464e2a0bab413",
	"vinicius@uritube.com",
	NULL,
	0,
    1,
	now()
);

INSERT INTO tbl_usuario VALUES (
	0, 
	"fulanin-119", 
	"Canal do fulaninho", 
	"ba3253876aed6bc22d4a6ff53d8406c6ad864195ed144ab5c87621b6c233b548baeae6956df346ec8c17f5ea10f35ee3cbc514797ed7ddd3145464e2a0bab413",
	"fulano@uritube.com",
	NULL,
	0,
    0,
	now()
);

CREATE TABLE tbl_usuario_removido (
	id INT NOT NULL PRIMARY KEY AUTO_INCREMENT,
	id_usuario INT NOT NULL,
	razao VARCHAR(100) NOT NULL,

	CONSTRAINT fk_id_usuario_on_tbl_usuario_removido
	FOREIGN KEY (id_usuario)
	REFERENCES tbl_usuario(id)
);

CREATE TABLE tbl_video (
	id INT NOT NULL PRIMARY KEY AUTO_INCREMENT,
	url_id VARCHAR(30) NOT NULL UNIQUE,
	titulo VARCHAR(100) NOT NULL,
	descricao VARCHAR(5000),
	visualizacoes INT NOT NULL,
	is_denunciado TINYINT NOT NULL,
	is_privado TINYINT NOT NULL,
	status VARCHAR(1000),
	status_err TINYINT NOT NULL,
	id_usuario INT,
	url_thumbnail VARCHAR(150) UNIQUE,
	duracao VARCHAR(50),
	criado_em TIMESTAMP NOT NULL,

	CONSTRAINT fk_id_usuario_on_tbl_video
	FOREIGN KEY (id_usuario)
	REFERENCES tbl_usuario(id)
);

-- SHOW COLLATION WHERE Charset = 'UTF8MB4';
ALTER TABLE tbl_video MODIFY COLUMN titulo VARCHAR(100) CHARACTER SET UTF8MB4 COLLATE UTF8MB4_UNICODE_CI;

ALTER TABLE tbl_video MODIFY COLUMN descricao VARCHAR(5000) CHARACTER SET UTF8MB4 COLLATE UTF8MB4_UNICODE_CI;

CREATE TABLE tbl_video_removido (
	id INT NOT NULL PRIMARY KEY AUTO_INCREMENT,
	id_video INT NOT NULL,
	razao VARCHAR(100) NOT NULL,

	CONSTRAINT fk_id_video_on_tbl_video_removido
	FOREIGN KEY (id_video)
	REFERENCES tbl_video(id)
);

CREATE TABLE tbl_comentario (
	id INT NOT NULL PRIMARY KEY AUTO_INCREMENT,
	id_usuario INT NOT NULL,
	id_video INT NOT NULL,
	comentario VARCHAR(9999) NOT NULL,
	criado_em TIMESTAMP NOT NULL,
	is_editado TINYINT NOT NULL,

	CONSTRAINT fk_id_usuario_on_tbl_comentario
	FOREIGN KEY (id_usuario)
	REFERENCES tbl_usuario(id),

	CONSTRAINT fk_id_video_on_tbl_comentario
	FOREIGN KEY (id_video)
	REFERENCES tbl_video(id)
);

CREATE TABLE tbl_inscricao (
	id INT NOT NULL PRIMARY KEY AUTO_INCREMENT,
	id_usuario_inscrito INT NOT NULL,
	id_usuario_principal INT NOT NULL,

	CONSTRAINT fk_id_usuario_inscrito_on_tbl_inscricao
	FOREIGN KEY (id_usuario_inscrito)
	REFERENCES tbl_usuario(id),

	CONSTRAINT fk_id_usuario_principal_on_tbl_inscricao
	FOREIGN KEY (id_usuario_principal)
	REFERENCES tbl_usuario(id)
);

CREATE TABLE tbl_notificacao (
	id INT NOT NULL PRIMARY KEY AUTO_INCREMENT,
	id_inscricao INT NOT NULL,
	id_video INT NOT NULL,
	leu TINYINT NOT NULL,

	CONSTRAINT fk_id_inscricao_on_tbl_notificacao
	FOREIGN KEY (id_inscricao)
	REFERENCES tbl_inscricao(id),

	CONSTRAINT fk_id_video_on_tbl_notificacao
	FOREIGN KEY (id_video)
	REFERENCES tbl_video(id)
);

CREATE TABLE tbl_reacao_video (
	id INT NOT NULL PRIMARY KEY AUTO_INCREMENT,
	gostei TINYINT NOT NULL,
    id_video INT NOT NULL,
    id_usuario INT NOT NULL,

	CONSTRAINT fk_id_usuario_on_tbl_reacao_video
	FOREIGN KEY (id_usuario)
	REFERENCES tbl_usuario(id),

	CONSTRAINT fk_id_video_on_tbl_reacao_video
	FOREIGN KEY (id_video)
	REFERENCES tbl_video(id)
);

CREATE TABLE tbl_reacao_comentario (
	id INT NOT NULL PRIMARY KEY AUTO_INCREMENT,
	gostei TINYINT NOT NULL,
    id_comentario INT NOT NULL,
    id_usuario INT NOT NULL,

	CONSTRAINT fk_id_usuario_on_tbl_reacao_comentario
	FOREIGN KEY (id_usuario)
	REFERENCES tbl_usuario(id),

	CONSTRAINT fk_id_comentario_on_tbl_reacao_comentario
	FOREIGN KEY (id_comentario)
	REFERENCES tbl_comentario(id)
);